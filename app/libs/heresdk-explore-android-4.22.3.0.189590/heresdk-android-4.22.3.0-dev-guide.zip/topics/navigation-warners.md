# Stay aware with warners

The `Navigator` and the `VisualNavigator` offer an extended warner system that allows you to receive notifications for certain events during tracking or during turn-by-turn navigation. Warners help you to drive safely or to receive information that may be useful to know in advance.

Note that not all warners alert on dangerous situations - many warners serve informational purposes such as knowing the current road attributes.

The most common warning events are:

- `TruckRestrictionWarning`: Notifies on upcoming truck obstacles that violate the set truck specifications (such as height or weight), or when trucks are not allowed to pass.
- `SafetyCameraWarning`: Notifies on upcoming safety spots (radar speed cameras).
- `SpeedLimit`: Receive a notification when the speed limit of the current road changes.
- `SpeedWarningStatus`: Notifies when the speed limit is exceeded.
- `SchoolZoneWarning`: A warning which notifies about a school zone presence on a road ahead where the speed limit is lower than the default speed limit on that road.
- `BorderCrossingWarning`: Notifies when country borders or states within a country are approached. Notifies also on the general speed limits that apply in the country or state.
- `RailwayCrossingWarning`: Notifies on upcoming railway crossings.
- `EnvironmentalZoneWarning`: Notifies when emission zones are approached.
- `DangerZoneWarning`: Notifies when a danger zone is approached that requires the attention of a driver.
- `LowSpeedZoneWarning`: Notifies when a low speed zone is approached that requires the attention of a driver.
- `TollStop`: Notifies on upcoming toll stops and which lane to take to reach a toll booth.
- `RealisticViewWarning`: Provides SVG content to show an upcoming junction with signposts.
- `RoadSignWarning`: Notifies on upcoming traffic signs, such as stop signs.
- `RoadAttributes`: Notifies when the current road attributes change, for example, when reaching a tunnel, a bridge or a toll way.
- `ManeuverViewLaneAssistance`: Provides a list of `Lane` recommendations if the next route maneuver takes place at a junction - regardless if the junction is considered complex or not.
- `JunctionViewLaneAssistance`: Provides a list of `Lane` recommendations only for complex junctions - regardless if a maneuver takes place at the junction or not. This event is not delivered for non-complex junctions.
- `CurrentSituationLaneView`: Receive lane-based information on the access, type and direction of the lanes of the current road a user is driving on.
- `TrafficMergeWarning`: Notifies on upcoming warning for merging traffic to the current road.

## Configure notification distances

By default, the notification distances for emitting warnings for each `WarningType` are configured as follows:

 - `warningNotificationDistances.slowSpeedDistanceInMeters`: For roads in urban areas where a slow driving speed is expected, the event is sent 500 meters ahead, by default.
 - `warningNotificationDistances.regularSpeedDistanceInMeters`: For roads in rural areas where a regular driving speed is expected, the event is sent 750 meters ahead, by default.
 - `warningNotificationDistances.fastSpeedDistanceInMeters`: For roads such as highways where a higher driving speed is expected, the event is sent 1000 meters in advance by default.

> #### Note
> The `TimingProfile` defines the speed ranges categorized as fast, regular, and slow.

Distances for emitting warnings can be configured using `VisualNavigator`. This is achieved by calling `visualNavigator.setWarningNotificationDistances(..)`, which accepts a specified `WarningType` and an instance of `WarningNotificationDistances`. The example below shows how the notification distances for `RoadSignWarning` can be set:

{% codetabs name="Java", type="java" -%}
{% raw %}
// Get notification distances for road sign alerts from visual navigator.
WarningNotificationDistances warningNotificationDistances = visualNavigator.getWarningNotificationDistances(WarningType.ROAD_SIGN);
// The distance in meters for emitting warnings when the speed limit or current speed is fast. Defaults to 1500.
warningNotificationDistances.fastSpeedDistanceInMeters = 1600;
// The distance in meters for emitting warnings when the speed limit or current speed is regular. Defaults to 750.
warningNotificationDistances.regularSpeedDistanceInMeters = 800;
// The distance in meters for emitting warnings when the speed limit or current speed is slow. Defaults to 500.
warningNotificationDistances.slowSpeedDistanceInMeters = 600;

// Set the warning distance for road signs.
visualNavigator.setWarningNotificationDistances(WarningType.ROAD_SIGN, warningNotificationDistances);
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
// Get notification distances for road sign alerts from visual navigator.
val warningNotificationDistances = visualNavigator.getWarningNotificationDistances(WarningType.ROAD_SIGN)
// The distance in meters for emitting warnings when the speed limit or current speed is fast. Defaults to 1500.
warningNotificationDistances.fastSpeedDistanceInMeters = 1600
// The distance in meters for emitting warnings when the speed limit or current speed is regular. Defaults to 750.
warningNotificationDistances.regularSpeedDistanceInMeters = 800
// The distance in meters for emitting warnings when the speed limit or current speed is slow. Defaults to 500.
warningNotificationDistances.slowSpeedDistanceInMeters = 600

// Set the warning distances for road signs.
visualNavigator.setWarningNotificationDistances(
    WarningType.ROAD_SIGN,
    warningNotificationDistances
)
{% endraw %}
{%- endcodetabs %}`

> #### Note
> The `WarningNotificationDistances` apply only to warners that alert about specific locations or areas along the route. It does not impact the `SpeedLimitListener`, which is independent of location and activates when the speed limit is exceeded or returns to within limits.

For most warners, the notification threshold is configurable, here you can find more information: [notification frequency](navigation-optimization.md#adjust-the-notification-frequency).

> #### Note
> All warners are supported during tracking mode. This means that you will get events for each warning type also when driving freely around - without following a particular route or after a destination has been reached.

In addition, all warners are not specific for a route or the set `RouteOptions` - unless explicitly mentioned (like for [truck speed limits](navigation-warners.md#get-speed-limit-warnings)). For example, you may receive `TruckRestrictionWarning` events while following a pedestrian route - if you wish so. In general, warner events are generated based on the map-matched location fed into the navigator. For example, pedestrian routes are most often map-matched to the same side of the road as for other transport modes ignoring sideways due to the precision of the GPS signal.

> #### Note
> Sometimes an application may want to warn on certain danger spots. For example, to display the distance to an obstacle that is ahead of a vehicle. For such cases consider to use the convenient method `navigator.calculateRemainingDistanceInMeters​(GeoCoordinates coordinates)` which provides the distance between the current location of the user on the route and the given `coordinates` - if they are on the route ahead. If the `coordinates` are already behind or not on the route at all, `null` is returned. Note that this method requires that the app knows the `coordinates` of the spot ahead in question.

Find more information on each warner in the sections below.

## Get speed limit warnings

By implementing the `SpeedLimitListener` you can receive events on the speed limits that are available along a road. These can be the speed limits as indicated on the local signs, as well as warnings on special speed situations, like for example, speed limits that are only valid for specific weather conditions.

Speed limits that are marked as conditional may be time-dependent. For example, speed limits for school zones can be valid only for a specific time of the day. In this case, the HERE SDK compares the device time with the time range of the speed limit. If the speed limit is currently valid, it will be propagated as event, otherwise not.

An implementation example can be found in the "Navigation" example app you can find on [GitHub](https://github.com/heremaps/here-sdk-examples):

{% codetabs name="Java", type="java" -%}
{% raw %}
// Notifies on the current speed limit valid on the current road.
visualNavigator.setSpeedLimitListener(new SpeedLimitListener() {
    @Override
    public void onSpeedLimitUpdated(@NonNull SpeedLimit speedLimit) {
        Double currentSpeedLimit = getCurrentSpeedLimit(speedLimit);

        if (currentSpeedLimit == null) {
            Log.d(TAG, "Warning: Speed limits unknown, data could not be retrieved.");
        } else if (currentSpeedLimit == 0) {
            Log.d(TAG, "No speed limits on this road! Drive as fast as you feel safe ...");
        } else {
            Log.d(TAG, "Current speed limit (m/s):" + currentSpeedLimit);
        }
    }
});

private Double getCurrentSpeedLimit(SpeedLimit speedLimit) {

    // Note that all values can be null if no data is available.

    // The regular speed limit if available. In case of unbounded speed limit, the value is zero.
    Log.d(TAG,"speedLimitInMetersPerSecond: " + speedLimit.speedLimitInMetersPerSecond);

    // A conditional school zone speed limit as indicated on the local road signs.
    Log.d(TAG,"schoolZoneSpeedLimitInMetersPerSecond: " + speedLimit.schoolZoneSpeedLimitInMetersPerSecond);

    // A conditional time-dependent speed limit as indicated on the local road signs.
    // It is in effect considering the current local time provided by the device's clock.
    Log.d(TAG,"timeDependentSpeedLimitInMetersPerSecond: " + speedLimit.timeDependentSpeedLimitInMetersPerSecond);

    // A conditional non-legal speed limit that recommends a lower speed,
    // for example, due to bad road conditions.
    Log.d(TAG,"advisorySpeedLimitInMetersPerSecond: " + speedLimit.advisorySpeedLimitInMetersPerSecond);

    // A weather-dependent speed limit as indicated on the local road signs.
    // The HERE SDK cannot detect the current weather condition, so a driver must decide
    // based on the situation if this speed limit applies.
    Log.d(TAG,"fogSpeedLimitInMetersPerSecond: " + speedLimit.fogSpeedLimitInMetersPerSecond);
    Log.d(TAG,"rainSpeedLimitInMetersPerSecond: " + speedLimit.rainSpeedLimitInMetersPerSecond);
    Log.d(TAG,"snowSpeedLimitInMetersPerSecond: " + speedLimit.snowSpeedLimitInMetersPerSecond);

    // For convenience, this returns the effective (lowest) speed limit between
    // - speedLimitInMetersPerSecond
    // - schoolZoneSpeedLimitInMetersPerSecond
    // - timeDependentSpeedLimitInMetersPerSecond
    return speedLimit.effectiveSpeedLimitInMetersPerSecond();
}
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
// Notifies on the current speed limit valid on the current road.
// Notifies on the current speed limit valid on the current road.
visualNavigator.speedLimitListener = SpeedLimitListener { speedLimit: SpeedLimit ->
    val currentSpeedLimit = getCurrentSpeedLimit(speedLimit)
    if (currentSpeedLimit == null) {
        Log.d(TAG, "Warning: Speed limits unknown, data could not be retrieved.")
    } else if (currentSpeedLimit == 0.0) {
        Log.d(TAG, "No speed limits on this road! Drive as fast as you feel safe ...")
    } else {
        Log.d(TAG, "Current speed limit (m/s): $currentSpeedLimit")
    }
}

private fun getCurrentSpeedLimit(speedLimit: SpeedLimit): Double? {
    // Note that all values can be null if no data is available.

    // The regular speed limit if available. In case of unbounded speed limit, the value is zero.

    Log.d(TAG, "speedLimitInMetersPerSecond: " + speedLimit.speedLimitInMetersPerSecond)

    // A conditional school zone speed limit as indicated on the local road signs.
    Log.d(
        TAG,
        "schoolZoneSpeedLimitInMetersPerSecond: " + speedLimit.schoolZoneSpeedLimitInMetersPerSecond
    )

    // A conditional time-dependent speed limit as indicated on the local road signs.
    // It is in effect considering the current local time provided by the device's clock.
    Log.d(
        TAG,
        "timeDependentSpeedLimitInMetersPerSecond: " + speedLimit.timeDependentSpeedLimitInMetersPerSecond
    )

    // A conditional non-legal speed limit that recommends a lower speed,
    // for example, due to bad road conditions.
    Log.d(
        TAG,
        "advisorySpeedLimitInMetersPerSecond: " + speedLimit.advisorySpeedLimitInMetersPerSecond
    )

    // A weather-dependent speed limit as indicated on the local road signs.
    // The HERE SDK cannot detect the current weather condition, so a driver must decide
    // based on the situation if this speed limit applies.
    Log.d(TAG, "fogSpeedLimitInMetersPerSecond: " + speedLimit.fogSpeedLimitInMetersPerSecond)
    Log.d(TAG, "rainSpeedLimitInMetersPerSecond: " + speedLimit.rainSpeedLimitInMetersPerSecond)
    Log.d(TAG, "snowSpeedLimitInMetersPerSecond: " + speedLimit.snowSpeedLimitInMetersPerSecond)

    // For convenience, this returns the effective (lowest) speed limit between
    // - speedLimitInMetersPerSecond
    // - schoolZoneSpeedLimitInMetersPerSecond
    // - timeDependentSpeedLimitInMetersPerSecond
    return speedLimit.effectiveSpeedLimitInMetersPerSecond()
}
{% endraw %}
{%- endcodetabs %}

Note that speed limits depend on the specified transport mode. Currently, the HERE SDK differentiates for cars and trucks based on the legal commercial vehicle regulations per country (CVR). That means, the above `SpeedLimit` event can indicate a lower speed limit for trucks: for example, on a highway, the speed limit will be at most [80 km/h in Germany](https://ec.europa.eu/transport/road_safety/going_abroad/germany/speed_limits_en.htm) - while for cars there may be a speed limit indicated that is 130 km/h or higher. Use map version 32 or higher to get CVR speed limits. On lower map versions trucks will receive the same speed limits as cars. Note that the map version can be updated with the `MapUpdater` - even if there are no downloaded regions - as navigation will only request the map data of the same version that is currently stored into the map cache. Therefore, keep in mind that this applies to both, online and offline usage.

> #### Note
> For trucks, we recommend to also specify the `TruckSpecifications` inside the `RouteOptions`. The property `grossWeightInKilograms` can have an impact on the speed limit for trucks. For most countries this has an impact on the legally allowed speed limit. If no weight is set, only the legally highest allowed speed limits for trucks will be forwarded - as the HERE SDK will then assume the truck's weight is very low. Speed limits for trucks are determined according to the local commercial vehicle regulations (CVR). Note that some countries like Japan regulate this different. However, routes calculated for trucks will not deliver speed limits suitable for cars - for example, if your truck's weight is below 3.5 T, consider to calculate a car route instead.

For tracking mode, call `navigator.setTrackingTransportProfile(vehicleProfile)` and set a `VehicleProfile` with e.g. `TRUCK` transport mode if you are a truck driver - make sure to specify also other vehicle properties like weight according to your vehicle. Setting this profile will determine `speedLimit.effectiveSpeedLimitInMetersPerSecond()`, but it will not affect the regular speed limit (`speedLimit.speedLimitInMetersPerSecond`).

> #### Note
> For routes in **Japan**, you can set the special flag `isLightTruck` via `TruckSpecifications`. This flag indicates whether the truck is light enough to be classified as a car. The flag should not be used in countries other than Japan. Note that this is a beta release of this feature.

## Get overspeed warnings

Although you can detect when you exceed speed limits yourself when you receive a new speed limit event (see above), there is a more convenient solution that can help you implement a speed warning feature for your app.

> #### Note
> This does not warn when temporary speed limits such as weather-dependent speed limits are exceeded.

The `onSpeedWarningStatusChanged()` method will notify as soon as the driver exceeds the current speed limit allowed. It will also notify as soon as the driver is driving slower again after exceeding the speed limit:

{% codetabs name="Java", type="java" -%}
{% raw %}
// Notifies when the current speed limit is exceeded.
visualNavigator.setSpeedWarningListener(new SpeedWarningListener() {
    @Override
    public void onSpeedWarningStatusChanged(SpeedWarningStatus speedWarningStatus) {
        if (speedWarningStatus == SpeedWarningStatus.SPEED_LIMIT_EXCEEDED) {
            // Driver is faster than current speed limit (plus an optional offset).
            // Play a notification sound to alert the driver.
            // Note that this may not include temporary special speed limits, see SpeedLimitListener.
            Uri ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone ringtone = RingtoneManager.getRingtone(context, ringtoneUri);
            ringtone.play();
        }

        if (speedWarningStatus == SpeedWarningStatus.SPEED_LIMIT_RESTORED) {
            Log.d(TAG, "Driver is again slower than current speed limit (plus an optional offset).");
        }
    }
});
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
// Notifies when the current speed limit is exceeded.
visualNavigator.speedWarningListener =
    SpeedWarningListener { speedWarningStatus: SpeedWarningStatus ->
    if (speedWarningStatus == SpeedWarningStatus.SPEED_LIMIT_EXCEEDED) {
        // Driver is faster than current speed limit (plus an optional offset).
        // Play a notification sound to alert the driver.
        // Note that this may not include temporary special speed limits, see SpeedLimitListener.
        val ringtoneUri =
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val ringtone = RingtoneManager.getRingtone(context, ringtoneUri)
        ringtone.play()
    }
    if (speedWarningStatus == SpeedWarningStatus.SPEED_LIMIT_RESTORED) {
        Log.d(
            TAG,
            "Driver is again slower than current speed limit (plus an optional offset)."
        )
    }
}
{% endraw %}
{%- endcodetabs %}

> #### Note
> Note that `onSpeedWarningStatusChanged()` does not notify when there is no speed limit data available. This information is only available as part of a `NavigableLocation` instance.

A `SpeedWarningStatus` is only delivered once the current speed is exceeded or when it is restored again - for example, when a driver is constantly driving too fast, only one event is fired.

The `onSpeedWarningStatusChanged()` notification is dependent on the current road's speed limits and the driver's speed. This means that you can get speed warning events also in tracking mode independent of a route. And, consequently, you can receive a `SPEED_LIMIT_RESTORED` event when the route has changed - after driver's speed slows again.

Optionally, you can define an offset that is added to the speed limit value. You will be notified only when you exceed the speed limit, including the offset. Below, we define two offsets, one for lower and one for higher speed limits. The boundary is defined by `highSpeedBoundaryInMetersPerSecond`:

{% codetabs name="Java", type="java" -%}
{% raw %}
private void setupSpeedWarnings() {
    SpeedLimitOffset speedLimitOffset = new SpeedLimitOffset();
    speedLimitOffset.lowSpeedOffsetInMetersPerSecond = 2;
    speedLimitOffset.highSpeedOffsetInMetersPerSecond = 4;
    speedLimitOffset.highSpeedBoundaryInMetersPerSecond = 25;

    visualNavigator.setSpeedWarningOptions(new SpeedWarningOptions(speedLimitOffset));
}
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
private fun setupSpeedWarnings(visualNavigator: VisualNavigator) {
    val speedLimitOffset = SpeedLimitOffset()
    speedLimitOffset.lowSpeedOffsetInMetersPerSecond = 2.0
    speedLimitOffset.highSpeedOffsetInMetersPerSecond = 4.0
    speedLimitOffset.highSpeedBoundaryInMetersPerSecond = 25.0

    visualNavigator.speedWarningOptions = SpeedWarningOptions(speedLimitOffset)
}
{% endraw %}
{%- endcodetabs %}

Here we set the `highSpeedBoundaryInMetersPerSecond` to 25 m/s: if a speed limit sign is showing a value above 25 m/s, the offset used is `highSpeedOffsetInMetersPerSecond`. If it is below 25 m/s, the offset used is `lowSpeedOffsetInMetersPerSecond`.

For the example values used above,

- if the speed limit on the road is 27 m/s, the (high) speed offset used is 4 m/s. This means we will only receive a warning notification when we are driving above 31 m/s = 27 m/s + 4 m/s. The `highSpeedOffsetInMetersPerSecond` is used, as the current speed limit is greater than `highSpeedBoundaryInMetersPerSecond`.

- if the speed limit on the road is 20 m/s, the (low) speed offset used is 2 m/s. This means we will only receive a warning notification when we are driving above 22 m/s = 20 m/s + 2 m/s. The `lowSpeedOffsetInMetersPerSecond` is used, as the current speed limit is smaller than `highSpeedBoundaryInMetersPerSecond`.

You can also set negative offset values. This may be useful if you want to make sure you never exceed the speed limit by having a buffer before you reach the limit. Note that you will never get notifications when you drive  too slow, for example, slower than a defined offset - unless a previous speed warning has been restored.

> #### Note
> Regarding the vehicle specifications, the same rules apply as mentioned above for speed limits.

## Get road sign warnings

Along a road you can find many shields. While driving you can receive detailed notifications on these shields by setting a `RoadSignWarningListener`.

The resulting `RoadSignWarning` event contains information on the shield, including information such as `RoadSignType` and `RoadSignCategory`.

The HERE SDK provides various `RoadSignType` values that can be retrieved from `RoadSignWarning` events. In general, the visual appearance of the road signs can differ across countries. However, some signs are standardized and look almost the same in all countries, such as `STOP_SIGN`. The list of available `RoadSignType` values can be found [here](https://www.here.com/docs/bundle/sdk-for-android-navigate-api-reference/page/com/here/sdk/navigation/RoadSignType.html).

Note that the actual road sign icons are `not` provided by the HERE SDK - this event delivers only information on the type of the sign, but no visuals of the sign itself. Also, the exact location of the traffic sign is not provided - however, since the ahead-distance information is provided, an application can notify when the sign is reached: for example, the `RouteProgress` event delivers constantly information about the travelled distance of a vehicle.

With `RoadSignWarningOptions` you can set a filter on which shields you want to get notified.

<center><p>
  <img src="../graphics/road_shields.jpg" width="450" style="box-shadow: 0 0 20px" />
  <figcaption>Some examples of priority road signs (not included in the HERE SDK).</figcaption>
</p></center>

Note that not all road shields are included. `RoadSignType` lists all supported types. For example, road signs showing speed limits are excluded, as these shields can be detected with the dedicated `SpeedLimitListener`.

The below code snippet shows a usage example:

{% codetabs name="Java", type="java" -%}
{% raw %}
RoadSignWarningOptions roadSignWarningOptions = new RoadSignWarningOptions();
// Set a filter to get only shields relevant for TRUCKS and HEAVY_TRUCKS.
roadSignWarningOptions.vehicleTypesFilter = Arrays.asList(RoadSignVehicleType.TRUCKS, RoadSignVehicleType.HEAVY_TRUCKS);
visualNavigator.setRoadSignWarningOptions(roadSignWarningOptions);

// Notifies on road shields as they appear along the road.
visualNavigator.setRoadSignWarningListener(new RoadSignWarningListener() {
    @Override
    public void onRoadSignWarningUpdated(@NonNull RoadSignWarning roadSignWarning) {
        Log.d(TAG, "Road sign distance (m): " + roadSignWarning.distanceToRoadSignInMeters);
        Log.d(TAG, "Road sign type: " + roadSignWarning.type.name());

        if (roadSignWarning.signValue != null) {
            // Optional text as it is printed on the local road sign.
            Log.d(TAG, "Road sign text: " + roadSignWarning.signValue.text);
        }

        // For more road sign attributes, please check the API Reference.
    }
});
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
val roadSignWarningOptions = RoadSignWarningOptions()
// Set a filter to get only shields relevant for TRUCKS and HEAVY_TRUCKS.
roadSignWarningOptions.vehicleTypesFilter = listOf(RoadSignVehicleType.TRUCKS, RoadSignVehicleType.HEAVY_TRUCKS)

// Notifies on road shields as they appear along the road.
visualNavigator.roadSignWarningListener =
RoadSignWarningListener { roadSignWarning: RoadSignWarning ->
    Log.d(TAG, "Road sign distance (m): " + roadSignWarning.distanceToRoadSignInMeters)
    Log.d(TAG, "Road sign type: " + roadSignWarning.type.name)

    if (roadSignWarning.signValue != null) {
        // Optional text as it is printed on the local road sign.
        Log.d(TAG, "Road sign text: " + roadSignWarning.signValue!!.text)
    }
    // For more road sign attributes, please check the API Reference.
}
{% endraw %}
{%- endcodetabs %}

`RoadSignWarning` events are issued exactly two times:

- When `DistanceType` is `AHEAD` and `distanceToRoadSignInMeters` is > 0.
- When `DistanceType` is `PASSED` and `distanceToRoadSignInMeters` is 0.

> #### Note
> For positional warners that notify on a singular object along a road, such as a safety camera, a road sign or a realistic view, there is always only one active warning happening at a time: this means that after each `AHEAD` event always a `PASSED` event will follow to avoid cases where two `AHEAD` warnings for a single object are active at the same time.

## Get toll collection point warnings

Another warner type is the `TollStopWarningListener` that provides events on upcoming toll booths.

This includes also information on payment details for vignettes such as window sticker or road taxes.

Like all warners, the event will be issued in tracking mode and during turn-by-turn navigation.

Inside the `TollBoothLane` class you can find information which lanes at a toll stop are suitable per vehicle type, as well as other information such as the accepted payment methods.

{% codetabs name="Java", type="java" -%}
{% raw %}
// Notifies on upcoming toll stops. Uses the same notification
// thresholds as other warners and provides events with or without a route to follow.
visualNavigator.setTollStopWarningListener(new TollStopWarningListener() {
    @Override
    public void onTollStopWarning(@NonNull TollStop tollStop) {
        List<TollBoothLane> lanes = tollStop.lanes;

        // The lane at index 0 is the leftmost lane adjacent to the middle of the road.
        // The lane at the last index is the rightmost lane.
        int laneNumber = 0;
        for (TollBoothLane tollBoothLane : lanes) {
            // Log which vehicles types are allowed on this lane that leads to the toll booth.
            logLaneAccess(laneNumber, tollBoothLane.access);
            TollBooth tollBooth = tollBoothLane.booth;
            List<TollCollectionMethod> tollCollectionMethods = tollBooth.tollCollectionMethods;
            List<PaymentMethod> paymentMethods = tollBooth.paymentMethods;
            // The supported collection methods like ticket or automatic / electronic.
            for (TollCollectionMethod collectionMethod : tollCollectionMethods) {
                Log.d(TAG,"This toll stop supports collection via: " + collectionMethod.name());
            }
            // The supported payment methods like cash or credit card.
            for (PaymentMethod paymentMethod : paymentMethods) {
                Log.d(TAG,"This toll stop supports payment via: " + paymentMethod.name());
            }
            laneNumber++;
        }
    }
});

private void logLaneAccess(int laneNumber, LaneAccess laneAccess) {
    Log.d(TAG,"Lane access for lane " + laneNumber);
    Log.d(TAG,"Automobiles are allowed on this lane: " + laneAccess.automobiles);
    Log.d(TAG,"Buses are allowed on this lane: " + laneAccess.buses);
    Log.d(TAG,"Taxis are allowed on this lane: " + laneAccess.taxis);
    Log.d(TAG,"Carpools are allowed on this lane: " + laneAccess.carpools);
    Log.d(TAG,"Pedestrians are allowed on this lane: " + laneAccess.pedestrians);
    Log.d(TAG,"Trucks are allowed on this lane: " + laneAccess.trucks);
    Log.d(TAG,"ThroughTraffic is allowed on this lane: " + laneAccess.throughTraffic);
    Log.d(TAG,"DeliveryVehicles are allowed on this lane: " + laneAccess.deliveryVehicles);
    Log.d(TAG,"EmergencyVehicles are allowed on this lane: " + laneAccess.emergencyVehicles);
    Log.d(TAG,"Motorcycles are allowed on this lane: " + laneAccess.motorcycles);
}
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
// Notifies on upcoming toll stops. Uses the same notification
// thresholds as other warners and provides events with or without a route to follow.
visualNavigator.tollStopWarningListener = TollStopWarningListener {
tollStop: TollStop ->
    val lanes = tollStop.lanes
    // The lane at index 0 is the leftmost lane adjacent to the middle of the road.
    // The lane at the last index is the rightmost lane.
    var laneNumber = 0
    for (tollBoothLane in lanes) {
        // Log which vehicles types are allowed on this lane that leads to the toll booth.
        logLaneAccess(laneNumber, tollBoothLane.access)
        val tollBooth = tollBoothLane.booth
        val tollCollectionMethods = tollBooth.tollCollectionMethods
        val paymentMethods = tollBooth.paymentMethods
        // The supported collection methods like ticket or automatic / electronic.
        for (collectionMethod in tollCollectionMethods) {
            Log.d(
                TAG,
                "This toll stop supports collection via: " + collectionMethod.name
            )
        }
        // The supported payment methods like cash or credit card.
        for (paymentMethod in paymentMethods) {
            Log.d(TAG, "This toll stop supports payment via: " + paymentMethod.name)
        }
        laneNumber++;
    }
}

private fun logLaneAccess(laneNumber: Int, laneAccess: LaneAccess) {
    Log.d(TAG, "Lane access for lane $laneNumber")
    Log.d(TAG, "Automobiles are allowed on this lane: " + laneAccess.automobiles)
    Log.d(TAG, "Buses are allowed on this lane: " + laneAccess.buses)
    Log.d(TAG, "Taxis are allowed on this lane: " + laneAccess.taxis)
    Log.d(TAG, "Carpools are allowed on this lane: " + laneAccess.carpools)
    Log.d(TAG, "Pedestrians are allowed on this lane: " + laneAccess.pedestrians)
    Log.d(TAG, "Trucks are allowed on this lane: " + laneAccess.trucks)
    Log.d(TAG, "ThroughTraffic is allowed on this lane: " + laneAccess.throughTraffic)
    Log.d(TAG, "DeliveryVehicles are allowed on this lane: " + laneAccess.deliveryVehicles)
    Log.d(TAG, "EmergencyVehicles are allowed on this lane: " + laneAccess.emergencyVehicles)
    Log.d(TAG, "Motorcycles are allowed on this lane: " + laneAccess.motorcycles)
}
{% endraw %}
{%- endcodetabs %}

Note that more information, like the exact price to pay and the location of a toll both is available as part of a `Route` object. Such information may be useful to extract from a route before starting the trip. For example, tapable `MapMarker` items can be used to indicate the toll stations along a route. During guidance, such detailed information could potentially distract a driver. Therefore, it is recommended to provide such information in advance.

## Get safety camera warnings

Safety cameras, commonly referred to as speed cameras or traffic cameras, are tools used to monitor and enforce traffic laws to increase road safety. They are typically installed at intersections, along busy roads, or in areas known for frequent traffic violations or accidents.

- You can attach a `SafetyCameraWarningListener` to the `Navigator` or `VisualNavigator` to get notified on `SafetyCameraWarning` events that inform on cameras that detect the speed of a driver.

- For most countries, this includes only permanently installed cameras. The HERE SDK does not inform whether the cameras are currently active - or not.

> #### Note
> Getting notifications on safety cameras - also know as "speed cameras" - is not available for all countries, due to the local laws and regulations. Note that for some countries, like in France, precise location information for speed cameras is disallowed by law: instead, here the notifications can only be given with less accuracy to meet the governmental guidelines. For most countries, however, precise location information is allowed.

While driving you can receive notifications on safety cameras by setting a `SafetyCameraWarningListener` as shown below:

{% codetabs name="Java", type="java" -%}
{% raw %}
// Notifies on safety camera warnings as they appear along the road.
visualNavigator.setSafetyCameraWarningListener(new SafetyCameraWarningListener() {
    @Override
    public void onSafetyCameraWarningUpdated(@NonNull SafetyCameraWarning safetyCameraWarning) {
        if (safetyCameraWarning.distanceType == DistanceType.AHEAD) {
            Log.d(TAG,"Safety camera warning " + safetyCameraWarning.type.name() + " ahead in: "
                    + safetyCameraWarning.distanceToCameraInMeters + "with speed limit ="
                    + safetyCameraWarning.speedLimitInMetersPerSecond + "m/s");
        } else if (safetyCameraWarning.distanceType == DistanceType.PASSED) {
            Log.d(TAG,"Safety camera warning " + safetyCameraWarning.type.name() + " passed: "
                    + safetyCameraWarning.distanceToCameraInMeters + "with speed limit ="
                    + safetyCameraWarning.speedLimitInMetersPerSecond + "m/s");
        } else if (safetyCameraWarning.distanceType == DistanceType.REACHED) {
            Log.d(TAG,"Safety camera warning " + safetyCameraWarning.type.name() + " reached at: "
                    + safetyCameraWarning.distanceToCameraInMeters + "with speed limit ="
                    + safetyCameraWarning.speedLimitInMetersPerSecond + "m/s");
        }
    }
});
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
// Notifies on safety camera warnings as they appear along the road.
visualNavigator.safetyCameraWarningListener =
    SafetyCameraWarningListener { safetyCameraWarning: SafetyCameraWarning ->
        if (safetyCameraWarning.distanceType == DistanceType.AHEAD) {
            Log.d(
                TAG,
                "Safety camera warning ${safetyCameraWarning.type.name} ahead in: " +
                        "${safetyCameraWarning.distanceToCameraInMeters} with speed limit = " +
                        "${safetyCameraWarning.speedLimitInMetersPerSecond} m/s"
            )
        } else if (safetyCameraWarning.distanceType == DistanceType.PASSED) {
            Log.d(
                TAG,
                "Safety camera warning ${safetyCameraWarning.type.name} passed: " +
                        "${safetyCameraWarning.distanceToCameraInMeters} with speed limit = " +
                        "${safetyCameraWarning.speedLimitInMetersPerSecond} m/s"
            )
        } else if (safetyCameraWarning.distanceType == DistanceType.REACHED) {
            Log.d(
                TAG,
                "Safety camera warning ${safetyCameraWarning.type.name} reached at: " +
                        "${safetyCameraWarning.distanceToCameraInMeters} with speed limit = " +
                        "${safetyCameraWarning.speedLimitInMetersPerSecond} m/s"
            )
        }
    }
{% endraw %}
{%- endcodetabs %}

As of now, the below listed countries are supported.

### Coverage for safety cameras

- Vietnam
- United States of America
- United Kingdom of Great Britain and Northern Ireland
- United Arab Emirates
- Ukraine
- Turkey
- Thailand
- Taiwan
- Sweden
- Spain
- South Africa
- Slovenia
- Slovakia
- Singapore
- Serbia
- Saudi Arabia
- Russian Federation
- Romania
- Qatar
- Portugal
- Poland
- Oman
- Norway
- New Zealand
- Netherlands
- Mexico
- Malta
- Malaysia
- Macao
- Luxembourg
- Lithuania
- Latvia
- Kuwait
- Korea, Republic of
- Kazakhstan
- Indonesia
- Italy
- Israel
- Isle of Man
- Iceland
- Hungary
- Hong Kong
- Greece
- France
- Finland
- Estonia
- Denmark
- Czechia
- Cyprus
- Croatia
- Chile
- Canada
- Cambodia
- Bulgaria
- Brazil
- Bosnia and Herzegovina
- Belgium
- Belarus
- Bahrain
- Azerbaijan
- Austria
- Australia
- Argentina
- Andorra

## Get school zone warnings

Similar to other warners, also a dedicated `SchoolZoneWarningListener` can be set:

{% codetabs name="Java", type="java" -%}
{% raw %}
// Notifies on school zones ahead.
visualNavigator.setSchoolZoneWarningListener(new SchoolZoneWarningListener() {
    @Override
    public void onSchoolZoneWarningUpdated(@NonNull List<SchoolZoneWarning> list) {
        // The list is guaranteed to be non-empty.
        for (SchoolZoneWarning schoolZoneWarning : list) {
            if (schoolZoneWarning.distanceType == DistanceType.AHEAD) {
                Log.d(TAG, "A school zone ahead in: " + schoolZoneWarning.distanceToSchoolZoneInMeters + " meters.");
                // Note that this will be the same speed limit as indicated by SpeedLimitListener, unless
                // already a lower speed limit applies, for example, because of a heavy truck load.
                Log.d(TAG, "Speed limit restriction for this school zone: " + schoolZoneWarning.speedLimitInMetersPerSecond + " m/s.");
                if (schoolZoneWarning.timeRule != null && !schoolZoneWarning.timeRule.appliesTo(new Date())) {
                    // For example, during night sometimes a school zone warning does not apply.
                    // If schoolZoneWarning.timeRule is null, the warning applies at anytime.
                    Log.d(TAG, "Note that this school zone warning currently does not apply.");
                }
            } else if (schoolZoneWarning.distanceType == DistanceType.REACHED) {
                Log.d(TAG, "A school zone has been reached.");
            } else if (schoolZoneWarning.distanceType == DistanceType.PASSED) {
                Log.d(TAG, "A school zone has been passed.");
            }
        }
    }
});
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
// Notifies on school zones ahead.
visualNavigator.schoolZoneWarningListener =
    SchoolZoneWarningListener { list: List<SchoolZoneWarning> ->
        // The list is guaranteed to be non-empty.
        for (schoolZoneWarning in list) {
            if (schoolZoneWarning.distanceType == DistanceType.AHEAD) {
                Log.d(TAG, "A school zone ahead in: " + schoolZoneWarning.distanceToSchoolZoneInMeters + " meters.")
                // Note that this will be the same speed limit as indicated by SpeedLimitListener, unless
                // already a lower speed limit applies, for example, because of a heavy truck load.
                Log.d(TAG, "Speed limit restriction for this school zone: " + schoolZoneWarning.speedLimitInMetersPerSecond + " m/s.")
                if (schoolZoneWarning.timeRule != null && !schoolZoneWarning.timeRule!!.appliesTo(Date())) {
                    // For example, during night sometimes a school zone warning does not apply.
                    // If schoolZoneWarning.timeRule is null, the warning applies at anytime.
                    Log.d(TAG, "Note that this school zone warning currently does not apply.")
                }
            } else if (schoolZoneWarning.distanceType == DistanceType.REACHED) {
                Log.d(TAG, "A school zone has been reached.")
            } else if (schoolZoneWarning.distanceType == DistanceType.PASSED) {
                Log.d(TAG, "A school zone has been passed.")
            }
        }
    }
{% endraw %}
{%- endcodetabs %}

Note that this warner notifies only about a school zone presence on a road ahead when the speed limit is lower than the default speed limit on that road - otherwise no alert is raised, even when there is a school ahead.

The notification threshold applies to all regions and can be set via `SchoolZoneWarningOptions`:

{% codetabs name="Java", type="java" -%}
{% raw %}
SchoolZoneWarningOptions schoolZoneWarningOptions = new SchoolZoneWarningOptions();
schoolZoneWarningOptions.filterOutInactiveTimeDependentWarnings = true;
schoolZoneWarningOptions.warningDistanceInMeters = 150;
visualNavigator.setSchoolZoneWarningOptions(schoolZoneWarningOptions);
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
val schoolZoneWarningOptions = SchoolZoneWarningOptions()
schoolZoneWarningOptions.filterOutInactiveTimeDependentWarnings = true
schoolZoneWarningOptions.warningDistanceInMeters = 150
visualNavigator.schoolZoneWarningOptions = schoolZoneWarningOptions
{% endraw %}
{%- endcodetabs %}

The default distance threshold can be found in the API Reference.

## Get border crossing warnings

Similar to other warners, also a dedicated `BorderCrossingWarning` notification can be received, which notifies whenever a border is crossed of a country. Optionally, the event notifies also when a state border of a country is crossed.

{% codetabs name="Java", type="java" -%}
{% raw %}
visualNavigator.setBorderCrossingWarningListener(new BorderCrossingWarningListener() {
    @Override
    public void onBorderCrossingWarningUpdated(@NonNull BorderCrossingWarning borderCrossingWarning) {
        // Since the border crossing warning is given relative to a single location,
        // the DistanceType.REACHED will never be given for this warning.
        if (borderCrossingWarning.distanceType == DistanceType.AHEAD) {
            Log.d(TAG, "BorderCrossing: A border is ahead in: " + borderCrossingWarning.distanceToBorderCrossingInMeters + " meters.");
            Log.d(TAG, "BorderCrossing: Type (such as country or state): " + borderCrossingWarning.type.name());
            Log.d(TAG, "BorderCrossing: Country code: " + borderCrossingWarning.countryCode.name());

            // The state code after the border crossing. It represents the state / province code.
            // It is a 1 to 3 upper-case characters string that follows the ISO 3166-2 standard,
            // but without the preceding country code (e.g. for Texas, the state code will be TX).
            // It will be null for countries without states or countries in which the states have very
            // similar regulations (e.g. for Germany there will be no state borders).
            if (borderCrossingWarning.stateCode != null) {
                Log.d(TAG, "BorderCrossing: State code: " + borderCrossingWarning.stateCode);
            }

            // The general speed limits that apply in the country / state after border crossing.
            GeneralVehicleSpeedLimits generalVehicleSpeedLimits = borderCrossingWarning.speedLimits;
            Log.d(TAG, "BorderCrossing: Speed limit in cities (m/s): " + generalVehicleSpeedLimits.maxSpeedUrbanInMetersPerSecond);
            Log.d(TAG, "BorderCrossing: Speed limit outside cities (m/s): " + generalVehicleSpeedLimits.maxSpeedRuralInMetersPerSecond);
            Log.d(TAG, "BorderCrossing: Speed limit on highways (m/s): " + generalVehicleSpeedLimits.maxSpeedHighwaysInMetersPerSecond);
        } else if (borderCrossingWarning.distanceType == DistanceType.PASSED) {
            Log.d(TAG, "BorderCrossing: A border has been passed.");
        }
    }
});
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
// Notifies whenever a border is crossed of a country and optionally, by default, also when a state
// border of a country is crossed.
visualNavigator.borderCrossingWarningListener =
    BorderCrossingWarningListener { borderCrossingWarning: BorderCrossingWarning ->
        // Since the border crossing warning is given relative to a single location,
        // the DistanceType.REACHED will never be given for this warning.
        if (borderCrossingWarning.distanceType == DistanceType.AHEAD) {
            Log.d(
                TAG,
                "BorderCrossing: A border is ahead in: " + borderCrossingWarning.distanceToBorderCrossingInMeters + " meters."
            )
            Log.d(TAG, "BorderCrossing: Type (such as country or state): " + borderCrossingWarning.type.name)
            Log.d(TAG, "BorderCrossing: Country code: " + borderCrossingWarning.countryCode.name)

            // The state code after the border crossing. It represents the state / province code.
            // It is a 1 to 3 upper-case characters string that follows the ISO 3166-2 standard,
            // but without the preceding country code (e.g. for Texas, the state code will be TX).
            // It will be null for countries without states or countries in which the states have very
            // similar regulations (e.g. for Germany there will be no state borders).
            if (borderCrossingWarning.stateCode != null) {
                Log.d(TAG, "BorderCrossing: State code: " + borderCrossingWarning.stateCode)
            }

            // The general speed limits that apply in the country / state after border crossing.
            val generalVehicleSpeedLimits = borderCrossingWarning.speedLimits
            Log.d(
                TAG,
                "BorderCrossing: Speed limit in cities (m/s): " + generalVehicleSpeedLimits.maxSpeedUrbanInMetersPerSecond
            )
            Log.d(
                TAG,
                "BorderCrossing: Speed limit outside cities (m/s): " + generalVehicleSpeedLimits.maxSpeedRuralInMetersPerSecond
            )
            Log.d(
                TAG,
                "BorderCrossing: Speed limit on highways (m/s): " + generalVehicleSpeedLimits.maxSpeedHighwaysInMetersPerSecond
            )
        } else if (borderCrossingWarning.distanceType == DistanceType.PASSED) {
            Log.d(TAG, "BorderCrossing: A border has been passed.")
        }
    }
{% endraw %}
{%- endcodetabs %}

With `BorderCrossingWarningOptions` you can specify a filter for border notifications.

{% codetabs name="Java", type="java" -%}
{% raw %}
BorderCrossingWarningOptions borderCrossingWarningOptions = new BorderCrossingWarningOptions();
// If set to true, all the state border crossing notifications will not be given.
// If the value is false, all border crossing notifications will be given for both
// country borders and state borders. Defaults to false.
borderCrossingWarningOptions.filterOutStateBorderWarnings = true;
visualNavigator.setBorderCrossingWarningOptions(borderCrossingWarningOptions);
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
val borderCrossingWarningOptions = BorderCrossingWarningOptions()
// If set to true, all the state border crossing notifications will not be given.
// If the value is false, all border crossing notifications will be given for both
// country borders and state borders. Defaults to false.
borderCrossingWarningOptions.filterOutStateBorderWarnings = true
visualNavigator.borderCrossingWarningOptions = borderCrossingWarningOptions
{% endraw %}
{%- endcodetabs %}

## Get danger zone warnings

Similar to other warners, also a dedicated `DangerZoneWarning` notification can be received, which notifies whenever a danger zone is approached.

A danger zone refers to areas where there is an increased risk of traffic incidents. These zones are designated to alert drivers to potential hazards and encourage safer driving behaviors.

Legally, certain devices can alert you to being in a danger zone, typically indicating the presence of a speed camera. In line with applicable law and industry standard, these alerts are usually provided along a road within a range of 4 km on a motorway, 2 km outside built-up areas, and 300 m in built-up areas​​.

The HERE SDK warns when approaching the danger zone, as well as when leaving such a zone. A danger zone may or may not have one or more speed cameras in it. The exact location of such speed cameras is not provided. Note that danger zones are only available in selected countries, such as France.

{% codetabs name="Java", type="java" -%}
{% raw %}
// Notifies on danger zones.
visualNavigator.setDangerZoneWarningListener(new DangerZoneWarningListener() {
    @Override
    public void onDangerZoneWarningsUpdated(@NonNull DangerZoneWarning dangerZoneWarning) {
        if (dangerZoneWarning.distanceType == DistanceType.AHEAD) {
            Log.d(TAG, "A danger zone ahead in: " + dangerZoneWarning.distanceInMeters + " meters.");
            // isZoneStart indicates if we enter the danger zone from the start.
            // It is false, when the danger zone is entered from a side street.
            // Based on the route path, the HERE SDK anticipates from where the danger zone will be entered.
            // In tracking mode, the most probable path will be used to anticipate from where
            // the danger zone is entered.
            Log.d(TAG, "isZoneStart: " + dangerZoneWarning.isZoneStart);
        } else if (dangerZoneWarning.distanceType == DistanceType.REACHED) {
            Log.d(TAG, "A danger zone has been reached. isZoneStart: " + dangerZoneWarning.isZoneStart);
        } else if (dangerZoneWarning.distanceType == DistanceType.PASSED) {
            Log.d(TAG, "A danger zone has been passed.");
        }
    }
});
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
visualNavigator.dangerZoneWarningListener =
    DangerZoneWarningListener { dangerZoneWarning: DangerZoneWarning ->
        if (dangerZoneWarning.distanceType == DistanceType.AHEAD) {
            Log.d(TAG, "A danger zone ahead in: ${dangerZoneWarning.distanceInMeters} meters.")
            // isZoneStart indicates if we enter the danger zone from the start.
            // It is false, when the danger zone is entered from a side street.
            // Based on the route path, the HERE SDK anticipates from where the danger zone will be entered.
            // In tracking mode, the most probable path will be used to anticipate from where
            // the danger zone is entered.
            Log.d(TAG, "isZoneStart: ${dangerZoneWarning.isZoneStart}")
        } else if (dangerZoneWarning.distanceType == DistanceType.REACHED) {
            Log.d(
                TAG,
                "A danger zone has been reached. isZoneStart: ${dangerZoneWarning.isZoneStart}"
            )
        } else if (dangerZoneWarning.distanceType == DistanceType.PASSED) {
            Log.d(TAG, "A danger zone has been passed.")
        }
    }
{% endraw %}
{%- endcodetabs %}

## Get low speed zone warnings

Similar to other warners, also a dedicated `LowSpeedZoneWarning` notification can be received, which notifies whenever a low speed zone is approached.

A "low speed zone" is an area where the speed limit is intentionally set lower than the surrounding areas to enhance safety and accommodate specific conditions. These zones are often implemented in places where higher speeds would pose a greater risk to pedestrians, cyclists, and other road users. Such zones can be also [visualized on the map view](map-styles.md) by showing the `MapFeatures.LOW_SPEED_ZONES`.

The HERE SDK warns when approaching the low speed zone, as well as when reaching or leaving such a zone.

{% codetabs name="Java", type="java" -%}
{% raw %}
// Notifies on low speed zones ahead - as indicated also on the map when MapFeatures.LOW_SPEED_ZONE is set.
visualNavigator.setLowSpeedZoneWarningListener(new LowSpeedZoneWarningListener() {
    @Override
    public void onLowSpeedZoneWarningUpdated(@NonNull LowSpeedZoneWarning lowSpeedZoneWarning) {
        if (lowSpeedZoneWarning.distanceType == DistanceType.AHEAD) {
            Log.d(TAG, "Low speed zone ahead in meters: " + lowSpeedZoneWarning.distanceToLowSpeedZoneInMeters);
            Log.d(TAG, "Speed limit in low speed zone (m/s): " + lowSpeedZoneWarning.speedLimitInMetersPerSecond);
        } else if (lowSpeedZoneWarning.distanceType == DistanceType.REACHED) {
            Log.d(TAG, "A low speed zone has been reached.");
            Log.d(TAG, "Speed limit in low speed zone (m/s): " + lowSpeedZoneWarning.speedLimitInMetersPerSecond);
        } else if (lowSpeedZoneWarning.distanceType == DistanceType.PASSED) {
            Log.d(TAG, "A low speed zone has been passed.");
        }
    }
});
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
// Notifies on low speed zones ahead - as indicated also on the map when MapFeatures.LOW_SPEED_ZONE is set.
visualNavigator.lowSpeedZoneWarningListener =
    LowSpeedZoneWarningListener { lowSpeedZoneWarning: LowSpeedZoneWarning ->
        if (lowSpeedZoneWarning.distanceType == DistanceType.AHEAD) {
            Log.d(
                TAG,
                "Low speed zone ahead in meters: ${lowSpeedZoneWarning.distanceToLowSpeedZoneInMeters}"
            )
            Log.d(
                TAG,
                "Speed limit in low speed zone (m/s): ${lowSpeedZoneWarning.speedLimitInMetersPerSecond}"
            )
        } else if (lowSpeedZoneWarning.distanceType == DistanceType.REACHED) {
            Log.d(TAG, "A low speed zone has been reached.")
            Log.d(
                TAG,
                "Speed limit in low speed zone (m/s): ${lowSpeedZoneWarning.speedLimitInMetersPerSecond}"
            )
        } else if (lowSpeedZoneWarning.distanceType == DistanceType.PASSED) {
            Log.d(TAG, "A low speed zone has been passed.")
        }
    }
{% endraw %}
{%- endcodetabs %}

## Get road attribute changes

By implementing the `RoadAttributesListener` you can receive events on the road attributes. The events are fired whenever an attribute changes - while you are traveling on that road.

{% codetabs name="Java", type="java" -%}
{% raw %}
// Notifies on the attributes of the current road including usage and physical characteristics.
visualNavigator.setRoadAttributesListener(new RoadAttributesListener() {
    @Override
    public void onRoadAttributesUpdated(@NonNull RoadAttributes roadAttributes) {
        // This is called whenever any road attribute has changed.
        // If all attributes are unchanged, no new event is fired.
        // Note that a road can have more than one attribute at the same time.

        Log.d(TAG, "Received road attributes update.");

        if (roadAttributes.isBridge) {
            // Identifies a structure that allows a road, railway, or walkway to pass over another road, railway,
            // waterway, or valley serving map display and route guidance functionalities.
            Log.d(TAG, "Road attributes: This is a bridge.");
        }
        if (roadAttributes.isControlledAccess) {
            // Controlled access roads are roads with limited entrances and exits that allow uninterrupted
            // high-speed traffic flow.
            Log.d(TAG, "Road attributes: This is a controlled access road.");
        }
        if (roadAttributes.isDirtRoad) {
            // Indicates whether the navigable segment is paved.
            Log.d(TAG, "Road attributes: This is a dirt road.");
        }
        if (roadAttributes.isDividedRoad) {
            // Indicates if there is a physical structure or painted road marking intended to legally prohibit
            // left turns in right-side driving countries, right turns in left-side driving countries,
            // and U-turns at divided intersections or in the middle of divided segments.
            Log.d(TAG, "Road attributes: This is a divided road.");
        }
        if (roadAttributes.isNoThrough) {
            // Identifies a no through road.
            Log.d(TAG, "Road attributes: This is a no through road.");
        }
        if (roadAttributes.isPrivate) {
            // Private identifies roads that are not maintained by an organization responsible for maintenance of
            // public roads.
            Log.d(TAG, "Road attributes: This is a private road.");
        }
        if (roadAttributes.isRamp) {
            // Range is a ramp: connects roads that do not intersect at grade.
            Log.d(TAG, "Road attributes: This is a ramp.");
        }
        if (roadAttributes.isRightDrivingSide) {
            // Indicates if vehicles have to drive on the right-hand side of the road or the left-hand side.
            // For example, in New York it is always true and in London always false as the United Kingdom is
            // a left-hand driving country.
            Log.d(TAG, "Road attributes: isRightDrivingSide = " + roadAttributes.isRightDrivingSide);
        }
        if (roadAttributes.isRoundabout) {
            // Indicates the presence of a roundabout.
            Log.d(TAG, "Road attributes: This is a roundabout.");
        }
        if (roadAttributes.isTollway) {
            // Identifies a road for which a fee must be paid to use the road.
            Log.d(TAG, "Road attributes change: This is a road with toll costs.");
        }
        if (roadAttributes.isTunnel) {
            // Identifies an enclosed (on all sides) passageway through or under an obstruction.
            Log.d(TAG, "Road attributes: This is a tunnel.");
        }
    }
});
}
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
// Notifies on the attributes of the current road including usage and physical characteristics.
visualNavigator.roadAttributesListener =
    RoadAttributesListener { roadAttributes: RoadAttributes ->
        // This is called whenever any road attribute has changed.
        // If all attributes are unchanged, no new event is fired.
        // Note that a road can have more than one attribute at the same time.

        Log.d(TAG, "Received road attributes update.")

        if (roadAttributes.isBridge) {
            // Identifies a structure that allows a road, railway, or walkway to pass over another road, railway,
            // waterway, or valley serving map display and route guidance functionalities.
            Log.d(TAG, "Road attributes: This is a bridge.")
        }
        if (roadAttributes.isControlledAccess) {
            // Controlled access roads are roads with limited entrances and exits that allow uninterrupted
            // high-speed traffic flow.
            Log.d(TAG, "Road attributes: This is a controlled access road.")
        }
        if (roadAttributes.isDirtRoad) {
            // Indicates whether the navigable segment is paved.
            Log.d(TAG, "Road attributes: This is a dirt road.")
        }
        if (roadAttributes.isDividedRoad) {
            // Indicates if there is a physical structure or painted road marking intended to legally prohibit
            // left turns in right-side driving countries, right turns in left-side driving countries,
            // and U-turns at divided intersections or in the middle of divided segments.
            Log.d(TAG, "Road attributes: This is a divided road.")
        }
        if (roadAttributes.isNoThrough) {
            // Identifies a no through road.
            Log.d(TAG, "Road attributes: This is a no through road.")
        }
        if (roadAttributes.isPrivate) {
            // Private identifies roads that are not maintained by an organization responsible for maintenance of
            // public roads.
            Log.d(TAG, "Road attributes: This is a private road.")
        }
        if (roadAttributes.isRamp) {
            // Range is a ramp: connects roads that do not intersect at grade.
            Log.d(TAG, "Road attributes: This is a ramp.")
        }
        if (roadAttributes.isRightDrivingSide) {
            // Indicates if vehicles have to drive on the right-hand side of the road or the left-hand side.
            // For example, in New York it is always true and in London always false as the United Kingdom is
            // a left-hand driving country.
            Log.d(
                TAG,
                "Road attributes: isRightDrivingSide = " + roadAttributes.isRightDrivingSide
            )
        }
        if (roadAttributes.isRoundabout) {
            // Indicates the presence of a roundabout.
            Log.d(TAG, "Road attributes: This is a roundabout.")
        }
        if (roadAttributes.isTollway) {
            // Identifies a road for which a fee must be paid to use the road.
            Log.d(TAG, "Road attributes change: This is a road with toll costs.")
        }
        if (roadAttributes.isTunnel) {
            // Identifies an enclosed (on all sides) passageway through or under an obstruction.
            Log.d(TAG, "Road attributes: This is a tunnel.")
        }
    }
{% endraw %}
{%- endcodetabs %}

An implementation example can be found in the "Navigation" example app you can find on [GitHub](https://github.com/heremaps/here-sdk-examples).

An application may decide to switch to a night map scheme as long as `roadAttributes.isTunnel` is true - this is not done automatically by the HERE SDK. Internally, the HERE SDK is using a tunnel interpolation algorithm to provide guidance in a tunnel - as usually the GPS signal is very weak or even lost while being in a tunnel.

### Get traffic merge warnings for merging roads ahead

Similar to other warners, also a dedicated `TrafficMergeWarning` notification can be received, which notifies you when upcoming roads merge with the current road.
The `TrafficMergeWarning` event describes the `RoadType` that is merging with the current road such as highway, slip road or a limited access road.
The HERE SDK warns when approaching or leaving a merging road. Since the event is given relative to a single position on the `Route`, the `REACHING` distance type is never given for this warning.

{% codetabs name="Java", type="java" -%}
{% raw %}
// Notifies about merging traffic to the current road.
visualNavigator.setTrafficMergeWarningListener(new TrafficMergeWarningListener() {
    @Override
    public void onTrafficMergeWarningUpdated(@NonNull TrafficMergeWarning trafficMergeWarning) {
        if (trafficMergeWarning.distanceType == DistanceType.AHEAD) {
            Log.d(TAG, "There is a merging " + trafficMergeWarning.roadType.name() + " ahead in: "
                    + trafficMergeWarning.distanceToTrafficMergeInMeters + "meters, merging from the "
                    + trafficMergeWarning.side.name() + "side, with lanes ="
                    + trafficMergeWarning.laneCount);
        } else if (trafficMergeWarning.distanceType == DistanceType.PASSED) {
            Log.d(TAG, "A merging " + trafficMergeWarning.roadType.name() + " passed: "
                    + trafficMergeWarning.distanceToTrafficMergeInMeters + "meters, merging from the "
                    + trafficMergeWarning.side.name() + "side, with lanes ="
                    + trafficMergeWarning.laneCount);
        } else if (trafficMergeWarning.distanceType == DistanceType.REACHED) {
            // Since the traffic merge warning is given relative to a single position on the route,
            // DistanceType.REACHED will never be given for this warning.
        }
    }
});
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
// Notifies about merging traffic to the current road.
visualNavigator.trafficMergeWarningListener =
    TrafficMergeWarningListener { trafficMergeWarning: TrafficMergeWarning ->
        if (trafficMergeWarning.distanceType == DistanceType.AHEAD) {
            Log.d(
                TAG,
                "There is a merging ${trafficMergeWarning.roadType.name} ahead in: " +
                        "${trafficMergeWarning.distanceToTrafficMergeInMeters} meters, merging from the " +
                        "${trafficMergeWarning.side.name} side, with lanes = ${trafficMergeWarning.laneCount}"
            )
        } else if (trafficMergeWarning.distanceType == DistanceType.PASSED) {
            Log.d(
                TAG,
                "A merging ${trafficMergeWarning.roadType.name} passed: " +
                        "${trafficMergeWarning.distanceToTrafficMergeInMeters} meters, merging from " +
                        "${trafficMergeWarning.side.name} side, with lanes = ${trafficMergeWarning.laneCount}"
            )
        } else if (trafficMergeWarning.distanceType == DistanceType.REACHED) {
            // Since the traffic merge warning is given relative to a single position on the route,
            // DistanceType.REACHED will never be given for this warning.
        }
    }
{% endraw %}
{%- endcodetabs %}

A text notification useful for TTS voice guidance, such as "Merging road ahead", can be optionally emitted alongside this warner notification via the `EventTextListener`. This can be enabled or disabled through the `TrafficMergeWarningOptions`.

## Get realistic view warnings

With the `RealisticViewWarningListener` you can receive SVG string data for signpost shields and complex junction views in 3D. The `RealisticViewWarning` event contains SVG data for both, signposts and junction views. Note that the warning is only delivered for complex junctions (see above).

{% codetabs name="Java", type="java" -%}
{% raw %}
RealisticViewWarningOptions realisticViewWarningOptions = new RealisticViewWarningOptions();
realisticViewWarningOptions.aspectRatio = AspectRatio.ASPECT_RATIO_3_X_4;
realisticViewWarningOptions.darkTheme = false;
visualNavigator.setRealisticViewWarningOptions(realisticViewWarningOptions);

// Notifies on signposts together with complex junction views.
// Signposts are shown as they appear along a road on a shield to indicate the upcoming directions and
// destinations, such as cities or road names.
// Junction views appear as a 3D visualization (as a static image) to help the driver to orientate.
//
// Optionally, you can use a feature-configuration to preload the assets as part of a Region.
//
// The event matches the notification for complex junctions, see JunctionViewLaneAssistance.
// Note that the SVG data for junction view is composed out of several 3D elements,
// a horizon and the actual junction geometry.
visualNavigator.setRealisticViewWarningListener(new RealisticViewWarningListener() {
    @Override
    public void onRealisticViewWarningUpdated(@NonNull RealisticViewWarning realisticViewWarning) {
        double distance = realisticViewWarning.distanceToRealisticViewInMeters;
        DistanceType distanceType = realisticViewWarning.distanceType;

        // Note that DistanceType.REACHED is not used for Signposts and junction views
        // as a junction is identified through a location instead of an area.
        if (distanceType == DistanceType.AHEAD) {
            Log.d(TAG, "A RealisticView ahead in: "+ distance + " meters.");
        } else if (distanceType == DistanceType.PASSED) {
            Log.d(TAG, "A RealisticView just passed.");
        }

        RealisticViewVectorImage realisticView = realisticViewWarning.realisticViewVectorImage;
        if (realisticView == null) {
            Log.d(TAG, "A RealisticView just passed. No SVG data delivered.");
            return;
        }

        String signpostSvgImageContent = realisticView.signpostSvgImageContent;
        String junctionViewSvgImageContent = realisticView.junctionViewSvgImageContent;
        // The resolution-independent SVG data can now be used in an application to visualize the image.
        // Use a SVG library of your choice to create an SVG image out of the SVG string.
        // Both SVGs contain the same dimension and the signpostSvgImageContent should be shown on top of
        // the junctionViewSvgImageContent.
        // The images can be quite detailed, therefore it is recommended to show them on a secondary display
        // in full size.
        Log.d("signpostSvgImage", signpostSvgImageContent);
        Log.d("junctionViewSvgImage", junctionViewSvgImageContent);
    }
});
{% endraw %}
{% language name="Kotlin", type="java" -%}
{% raw %}
val realisticViewWarningOptions = RealisticViewWarningOptions()
realisticViewWarningOptions.aspectRatio = AspectRatio.ASPECT_RATIO_3_X_4
realisticViewWarningOptions.darkTheme = false
visualNavigator.realisticViewWarningOptions = realisticViewWarningOptions
// Notifies on signposts together with complex junction views.
// Signposts are shown as they appear along a road on a shield to indicate the upcoming directions and
// destinations, such as cities or road names.
// Junction views appear as a 3D visualization (as a static image) to help the driver to orientate.
//
// Optionally, you can use a feature-configuration to preload the assets as part of a Region.
//
// The event matches the notification for complex junctions, see JunctionViewLaneAssistance.
// Note that the SVG data for junction view is composed out of several 3D elements,
// a horizon and the actual junction geometry.
visualNavigator.realisticViewWarningListener =
    RealisticViewWarningListener { realisticViewWarning: RealisticViewWarning ->
        val distance = realisticViewWarning.distanceToRealisticViewInMeters
        val distanceType = realisticViewWarning.distanceType

        // Note that DistanceType.REACHED is not used for Signposts and junction views
        // as a junction is identified through a location instead of an area.
        if (distanceType == DistanceType.AHEAD) {
            Log.d(
                TAG,
                "A RealisticView ahead in: $distance meters."
            )
        } else if (distanceType == DistanceType.PASSED) {
            Log.d(TAG, "A RealisticView just passed.")
        }

        val realisticView = realisticViewWarning.realisticViewVectorImage
        if (realisticView == null) {
            Log.d(TAG, "A RealisticView just passed. No SVG data delivered.")
            return@RealisticViewWarningListener
        }

        val signpostSvgImageContent = realisticView.signpostSvgImageContent
        val junctionViewSvgImageContent = realisticView.junctionViewSvgImageContent
        // The resolution-independent SVG data can now be used in an application to visualize the image.
        // Use a SVG library of your choice to create an SVG image out of the SVG string.
        // Both SVGs contain the same dimension and the signpostSvgImageContent should be shown on top of
        // the junctionViewSvgImageContent.
        // The images can be quite detailed, therefore it is recommended to show them on a secondary display
        // in full size.
        Log.d("signpostSvgImage", signpostSvgImageContent)
        Log.d("junctionViewSvgImage", junctionViewSvgImageContent)
    }
{% endraw %}
{%- endcodetabs %}

The `realisticView.signpostSvgImageContent` is meant to be overlayed on top of the `realisticView.junctionViewSvgImageContent`. Both images can be requested in the same aspect ratio. This way, both images will have the same dimensions and can be rendered at the same top-left position.

<center><p>
  <img src="../graphics/signposts.png" width="450" style="box-shadow: 0 0 20px" />
  <figcaption>Screenshot: A junction view overlayed with a signpost image.</figcaption>
</p></center>

Note that the HERE SDK only delivers the SVG as string, so you need to use a third-party library to render the SVG string content, such as [AndroidSVG](https://github.com/BigBadaboom/androidsvg). In order to use the correct fonts, the HERE SDK provides a free-to-use font package, see below.

> #### Note
> The data for junction views is optimized to occupy only around 2 MB, while the signpost data occupies only a few KB. However, it is recommended to use the available feature-configurations to preload the image data in advance, see our [Optimization Guide](optimization.md) for more details.

While you can use the 16:9 resolution in landscape format, you can use it also in portrait mode to not cover the full screen: however, since the SVG assets are quite detailed it is recommended to shown them fullscreen on a secondary display.

> #### Note
> For positional warners that notify on a singular object along a road, such as a safety camera, a road sign or a realistic view, there is always only one active warning happening at a time: this means that after each `AHEAD` event always a `PASSED` event will follow to avoid cases where two `AHEAD` warnings for a single object are active at the same time.

Take a look at the "Navigation" example app on [GitHub](https://github.com/heremaps/here-sdk-examples) for a usage example.

> #### Note
> The `RealisticViewVectorImage` feature is released as a beta release, so there could be a few bugs and unexpected behaviors. Related APIs may change for new releases without a deprecation process.

### Integrate a SVG renderer and HERE fonts

In order to render the signposts SVGs (see above), we recommend to use the [AndroidSVG](https://github.com/BigBadaboom/androidsvg) plugin. In addition, you need the required TTF fonts that are defined in the SVG content as font families. These fonts can be found in the HERE SDK distribution package.

1. Integrate `AndroidSVG` according to the instructions of the plugin vendor. Make sure to be okay with the license of the vendor. Modify the app's `build.gradle` file:

```xml
dependencies {
    implementation fileTree(dir: 'libs', include: ['*.aar', '*.jar'], exclude : ['*mock*.jar'])
    implementation 'androidx.appcompat:appcompat:1.3.1'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.1'

    // Needed for realistic views rendering that are provided as SVG strings.
    implementation 'com.caverock:androidsvg-aar:1.4'
}
```

2. Add the `import com.caverock.androidsvg.SVG;` statement to your code and check if the integration of the plugin was successful.

3. Extract the `SignpostFonts.zip` archive as found in the HERE SDK distribution package (the one that also contains the binaries for the HERE SDK). Copy the content to your project's `asset` folder: `YourApp/app/src/main/assets`. If not already existing, create the folder.

4. Create a font resolver class to load the needed fonts with Android's `AssetManager`. It is registered by the plugin in the next step. When the plugin needs to use a font, it will look it up via our resolver:

```java
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.util.Log;

import com.caverock.androidsvg.SVGExternalFileResolver;

// Needed by AndroidSVG plugin to render the provided fonts.
// Note: It has to be registered for use with the plugin.
public class FontResolver extends SVGExternalFileResolver {

    final private AssetManager assetManager;

    public FontResolver(AssetManager assetManager) {
        super();
        this.assetManager = assetManager;
    }

    @Override
    public Typeface resolveFont(String fontFamily, int fontWeight, String fontStyle) {
        try {
            return Typeface.createFromAsset(assetManager, getFontPath(fontFamily));
        } catch (RuntimeException exception) {
            Log.e("FontResolver", exception.getMessage());
        }

        return null;
    }

    private String getFontPath(String fontFamily) {
        switch (fontFamily) {
            case "FiraGO-Map":
                return "FiraGO_Map/FiraGO-Map.ttf";
            case "SignText-Bold":
                return "SignText/SignText-Bold.ttf";
            case "SignTextNarrow-Bold":
                return "SignTextNarrow/SignTextNarrow-Bold.ttf";
            case "SourceHanSansSC-Normal":
                return "SourceHanSansSC/TTF/SourceHanSansSC-Normal.ttf";

            default:
                Log.e("FontResolver", "Font not found: " + fontFamily);
                return "";
        }
    }
}
```

5. Render the SVG content:

```java
private void showRealisticViews(String signpostSvgImageContent, String junctionViewSvgImageContent) {
    ImageView signpostSvgImage = createImageView(signpostSvgImageContent);
    ImageView junctionViewSvgImage = createImageView(junctionViewSvgImageContent);

    if (signpostSvgImage == null || junctionViewSvgImage == null) {
        throw new RuntimeException("Unexpectedly, the SVG string could not be parsed.");
    }

    // Draw the signpost image on top of the junction view image.
    FrameLayout frameLayout = new FrameLayout(MainActivity.this);
    frameLayout.addView(junctionViewSvgImage);
    frameLayout.addView(signpostSvgImage);

    // Attention: In a production-app, be careful to not distract a driver.
    // It is recommended to show this on a secondary display that resets
    // automatically after some time or when the junction was passed.

    // ... now show the view.
}

private boolean registerFontResolver = true;

// Create a rendered bitmap from a raw SVG string.
// Requires com.caverock.androidsvg.SVG plugin.
@Nullable
private ImageView createImageView(String svgString) {
    // Register our font resolver with AndroidSVG.
    if (registerFontResolver) {
        registerFontResolver = false;
        SVG.registerExternalFileResolver(new FontResolver(getAssets()));
    }

    SVG svg;
    try {
        svg = SVG.getFromString(svgString);
    } catch (SVGParseException e) {
        e.printStackTrace();
        return null;
    }
    PictureDrawable pictureDrawable = new PictureDrawable(svg.renderToPicture());
    ImageView imageView = new ImageView(MainActivity.this);
    imageView.setImageDrawable(pictureDrawable);
    return imageView;
}
```

> #### Note
> The rasterization of the SVG content has to happen on the app-side. Depending on the GPU of the mobile device, rendering a full-screen image can take a while. Consider to move this to a worker thread to not block the UI thread.

As of now, the following TTF fonts are provided by the HERE SDK. They are free-to-use in your own commercial and non-commercial projects. Be sure to check the license file included in the `SignpostFonts.zip` archive for each font:

- **SourceHanSansSC-Normal.ttf:** This font is mainly used in Macao, Taiwan, Hong Kong.
- **FiraGO-Map.ttf:** This font is mainly used in Israel.
- **SignText-Bold.ttf:** This font is mainly used in Vietnam.
- **SignTextNarrow-Bold.ttf:** This font is used in all countries, except for the above countries.
<!-- See https://confluence.in.here.com/pages/viewpage.action?spaceKey=NAV&title=Handling+custom+fonts+in+Signpost+SVGs -->

> #### Note
> If a font family that is specified in the SVG content is not found, then usually the SVG plugin of your choice will render a default font which may not look as expected.

## Get environmental zone warnings

Environmental Zones, also known as Low Emission Zones (LEZ) or Clean Air Zones (CAZ), are designated areas within cities or regions where certain restrictions or regulations are implemented to improve air quality and reduce pollution. These zones aim to discourage or limit the entry of vehicles that emit high levels of pollutants, such as nitrogen dioxide (NO2) and particulate matter (PM).

The specific rules and regulations of environmental zones can vary between different cities and countries. Typically, vehicles that do not meet certain emission standards are either prohibited from entering the zone or required to pay a fee.

Environmental zone designations and their corresponding rules are typically determined by local or regional authorities in collaboration with transportation and environmental agencies.

The HERE SDK notifies on upcoming environmental zones like so:

```java
visualNavigator.setEnvironmentalZoneWarningListener(new EnvironmentalZoneWarningListener() {
    @Override
    public void onEnvironmentalZoneWarningsUpdated(@NonNull List<EnvironmentalZoneWarning> list) {
        // The list is guaranteed to be non-empty.
        for (EnvironmentalZoneWarning environmentalZoneWarning : list) {
            DistanceType distanceType = environmentalZoneWarning.distanceType;
            if (distanceType == DistanceType.AHEAD) {
                Log.d(TAG, "A EnvironmentalZone ahead in: "+ environmentalZoneWarning.distanceInMeters + " meters.");
            } else if (distanceType == DistanceType.REACHED) {
                Log.d(TAG, "A EnvironmentalZone has been reached.");
            } else if (distanceType == DistanceType.PASSED) {
                Log.d(TAG, "A EnvironmentalZone just passed.");
            }

            // The official name of the environmental zone (example: "Zone basse émission Bruxelles").
            String name = environmentalZoneWarning.name;
            // The description of the environmental zone for the default language.
            String description = environmentalZoneWarning.description.getDefaultValue();
            // The environmental zone ID - uniquely identifies the zone in the HERE map data.
            String zoneID = environmentalZoneWarning.zoneId;
            // The website of the environmental zone, if available - null otherwise.
            String websiteUrl = environmentalZoneWarning.websiteUrl;
            Log.d(TAG, "environmentalZoneWarning: description: " + description);
            Log.d(TAG, "environmentalZoneWarning: name: " + name);
            Log.d(TAG, "environmentalZoneWarning: zoneID: " + zoneID);
            Log.d(TAG, "environmentalZoneWarning: websiteUrl: " + websiteUrl);
        }
    }
});
```
