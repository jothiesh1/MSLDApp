# Examples and use cases

Explore practical examples and use cases to effectively utilize indoor maps and venues with the HERE SDK. This section covers a range of topics to help you get the most out of our indoor mapping capabilities.

## List all indoor maps

The HERE SDK for Android (_Navigate Edition_) allows you to list all private venues that are accessible for your account and the selected collection. `VenueMap` contains a list which holds `VenueInfo` elements containing venue identifier, venue ID and venue Name.

```java
List<VenueInfo> venueInfo = venueEngine.getVenueMap().getVenueInfoList();
for (int i = 0; i< venueInfo.size(); i++) {
    Log.d(TAG, "Venue Identifier: " + venueInfo.get(i).getVenueIdentifier() + " Venue Id: "+venueInfo.get(i).getVenueId() + " Venue Name: "+venueInfo.get(i).getVenueName());
}
```
For maps with venue identifier as UUID, `getVenueId()` would return 0.

## Load and show a venue

The HERE SDK for Android (_Navigate Edition_) allows you to load and visualize venues by `Identifier`. You must know the venue's identifier for the current set of credentials. There are several ways to load and visualize the venues.

`VenueMap` has two methods to add a venue to the map: `selectVenueAsync()` and `addVenueAsync()`. Both methods use `getVenueService().addVenueToLoad()` to load the venue by `Identifier` and then add it to the map. The method `selectVenueAsync()` also selects the venue:

```java
venueEngine.getVenueMap().selectVenueAsync(String venueIdentifier);
```

```java
venueEngine.getVenueMap().addVenueAsync(String venueIdentifier);
```

> #### Note
>
> For legacy maps with an `int` based venue ID, `VenueMap` still supports `selectVenueAsync(int venueID)` and `addVenueAsync(int venueID)` to load the venue by venue ID.

Once the venue is loaded, the `VenueService` calls the `VenueMapListener.onGetVenueCompleted()` method:

```java
// Listener for the venue loading event
private final VenueMapListener venueMapListener = (venueIdentifier, venueModel, online, venueStyle) -> {
    if (venueModel == null) {
        Log.e(TAG, "Failed to load the venue: " + venueIdentifier);
    }
};
```

> #### Note
>
> For legacy maps with an `int` based venue ID, `VenueService` calls the `VenueListener.onGetVenueCompleted(venueID, venueModel, online, venueStyle)` method.


Once the venue is loaded successfully, if you are using the `addVenueAsync()` method, only the `VenueMapLifecycleListener.onVenueAdded()` method will be triggered. If you are using the `selectVenueAsync()` method, the `VenueSelectionListener.onSelectedVenueChanged()` method will also be triggered:

```java
// Listener for the venue selection event.
private final VenueSelectionListener venueSelectionListener =
    (deselectedVenue, selectedVenue) -> {
        if (selectedVenue != null) {
            // Move camera to the selected venue.
            GeoCoordinates venueCenter = selectedVenue.getVenueModel().getCenter();
            final double distanceInMeters = 500;
            MapMeasure mapMeasureZoom = new MapMeasure(MapMeasure.Kind.DISTANCE_IN_METERS, distanceInMeters);
            mapView.getCamera().lookAt(
                    new GeoCoordinates(venueCenter.latitude, venueCenter.longitude),
                    mapMeasureZoom);
            // This functions is used to facilitate the toggling of topology visibility.
            // Setting isTopologyVisible property to true will render the topology on scene and false will lead to hide the topology.
            selectedVenue.setTopologyVisible(true);
        }
    };
```

A `Venue` can also be removed from the `VenueMap`, which triggers the `VenueMapLifecycleListener.onVenueRemoved(venueIdentifier)` method:

```java
venueEngine.getVenueMap().removeVenue(venue);
```

> #### Note
>
> For legacy maps with an `int` based venue ID, if you are using the `addVenueAsync()` method, the `VenueLifecycleListener.onVenueAdded()` method will be triggered.
> When removing an `int` based venue ID from `VenueMap`, the `VenueLifecycleListener.onVenueRemoved(venueID)` is triggered.


## Label text preference

You can override the default label text preference for a venue.

Once the `VenueEngine` is initialized, a callback is called. From this point on, there is access to the `VenueService`. The optional method `setLabeltextPreference()` can be called to set the label text preference during rendering. Overriding the default style label text preference provides an opportunity to set the following options as a list where the order defines the preference:

- "OCCUPANT_NAMES"
- "SPACE_NAME"
- "INTERNAL_ADDRESS"
- "SPACE_TYPE_NAME"
- "SPACE_CATEGORY_NAME"

These can be set in any desired order. For example, if the label text preference does not contain "OCCUPANT_NAMES" then it will switch to "SPACE_NAME" and so on, based on the order of the list. Nothing is displayed if no preference is found.

```java
private void onVenueEngineInitCompleted() {
    // Get VenueService and VenueMap objects.
    VenueService service = venueEngine.getVenueService();
    VenueMap venueMap = venueEngine.getVenueMap();

    // Add needed listeners.
    service.add(serviceListener);
    service.add(venueListener);
    venueMap.add(venueSelectionListener);

    // Start VenueEngine. Once authentication is done, the authentication callback
    // will be triggered. After, VenueEngine will start VenueService. Once VenueService
    // is initialized, VenueServiceListener.onInitializationCompleted method will be called.
    venueEngine.start((authenticationError, authenticationData) -> {
        if (authenticationError != null) {
            Log.e(TAG, "Failed to authenticate, reason: " + authenticationError.value);
        }
    });

    if(HRN != "") {
        // Set platform catalog HRN
        service.setHrn(HRN);
    }

    // Set label text preference
    service.setLabeltextPreference(LabelPref);
}
```

## Select venue drawings and levels

A `Venue` object allows you to control the state of the venue.

The methods `getSelectedDrawing()` and `setSelectedDrawing()` allow you to get and set a drawing which is visible on the map. When a new drawing is selected, the `VenueDrawingSelectionListener.onDrawingSelected()` method is triggered.

The following provides an example of how to select a drawing when an item is clicked in a `ListView`:

```java
@Override
public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
    VenueModel venueModel = venue.getVenueModel();
    // Set the selected drawing when a user clicks on the item in the list.
    venue.setSelectedDrawing(venueModel.getDrawings().get(position));
}
```

The methods `getSelectedLevelIndex()` and `setSelectedLevelIndex()` allow you to get and set a level based on the location within the list of levels. When a new level is selected, the `VenueLevelSelectionListener.onLevelSelected()` method is triggered.

The following provides an example of how to select a level based on a reversed levels list from `ListView`:

```java
listView.setOnItemClickListener((parent, view, position, id) -> {
    if (venueMap.getSelectedVenue() != null) {
        // Revers an index, as levels in LevelSwitcher appear in a different order
        venueMap.getSelectedVenue().setSelectedLevelIndex(maxLevelIndex - position);
    }
});
```

A full example of the UI switchers to control drawings and levels is available in the "IndoorMap" example app, available on [GitHub](https://github.com/heremaps/here-sdk-examples).

## Customize the style of a venue

You can change the visual style of `VenueGeometry` objects. Geometry style and/or label style objects must be created and provided to the `Venue.setCustomStyle()` method:

```java
private final VenueGeometryStyle geometryStyle = new VenueGeometryStyle(
        SELECTED_COLOR, SELECTED_OUTLINE_COLOR, 1);
private final VenueLabelStyle labelStyle = new VenueLabelStyle(
        SELECTED_TEXT_COLOR, SELECTED_TEXT_OUTLINE_COLOR, 1, 28);
```

```java
ArrayList<VenueGeometry> geometries =
        new ArrayList<>(Collections.singletonList(geometry));
venue.setCustomStyle(geometries, geometryStyle, labelStyle);
```

## Select space by identifier

The ID of spaces, levels and drawings can be extracted using `getIdentifier()`, e.g. for spaces call: `spaces.getIdentifier()`. Then, for using those id values, a specific space can be searched in a level or a drawing with `getGeometryById(String id)`.

```java
ArrayList<String> geometriesID;
ArrayList<VenueGeometry> geometries;
for(String id : geometriesID)
{
    VenueGeometry geometry = selectVenue.getSelectedDrawing().getGeometryById(id);
    geometries.add(geometry);
}
private final VenueGeometryStyle geometryStyle = new VenueGeometryStyle(
        SELECTED_COLOR, SELECTED_OUTLINE_COLOR, 1);
private final VenueLabelStyle labelStyle = new VenueLabelStyle(
        SELECTED_TEXT_COLOR, SELECTED_TEXT_OUTLINE_COLOR, 1, 28);
selectVenue.setCustomStyle(geometries, geometryStyle, labelStyle);
```

## Handle tap gestures on a venue

You can select a venue object by tapping it. First, set the tap listener:

```java
mapView.getGestures().setTapListener(tapListener);
```

Inside the tap listener, you can use the tapped geographic coordinates as parameter for the `VenueMap.getGeometry()` and `VenueMap.getVenue()` methods:

```java
private final TapListener tapListener = origin -> {
    deselectGeometry();

    // Get geo position of the tap.
    GeoCoordinates position = mapView.viewToGeoCoordinates(origin);
    if (position == null) {
        return;
    }

    VenueMap venueMap = venueEngine.getVenueMap();
    // Get VenueGeometry under the tapped position.
    VenueGeometry geometry = venueMap.getGeometry(position);

    if (geometry != null) {
        // If there is a geometry, put a marker on top of it.
        marker = new MapMarker(position, markerImage, new Anchor2D(0.5f, 1f));
        mapView.getMapScene().addMapMarker(marker);
    } else {
        // If no geometry was tapped, check if there is a not-selected venue under
        // the tapped position. If there is one, select it.
        Venue venue = venueMap.getVenue(position);
        if (venue != null) {
            venueMap.setSelectedVenue(venue);
        }
    }
};

private void deselectGeometry() {
    // If marker is already on the screen, remove it.
    if (marker != null) {
        mapView.getMapScene().removeMapMarker(marker);
    }
}
```

HERE recommends that you deselect the tapped geometry when the selected venue, drawing, or level has changed:

```java
private final VenueSelectionListener venueSelectionListener =
        (deselectedController, selectedController) -> deselectGeometry();

private final VenueDrawingSelectionListener drawingSelectionListener =
        (venue, deselectedController, selectedController) -> deselectGeometry();

private final VenueLevelSelectionListener levelChangeListener =
        (venue, drawing, oldLevel, newLevel) -> deselectGeometry();

void setVenueMap(VenueMap venueMap) {
    if (this.venueMap == venueMap) {
        return;
    }

    // Remove old venue map listeners.
    removeListeners();
    this.venueMap = venueMap;

    if (this.venueMap != null) {
        this.venueMap.add(venueSelectionListener);
        this.venueMap.add(drawingSelectionListener);
        this.venueMap.add(levelChangeListener);
        deselectGeometry();
    }
}

private void removeListeners() {

    if (this.venueMap != null) {
        this.venueMap.remove(venueSelectionListener);
        this.venueMap.remove(drawingSelectionListener);
        this.venueMap.remove(levelChangeListener);
    }
}
```

A full example showing usage of the map tap event with venues is available in the "IndoorMap" example app, available on [GitHub](https://github.com/heremaps/here-sdk-examples).
