# Optimize Positioning

Below, we present additional options for obtaining precise and reliable location data for a variety of applications.

## Specify location options

If you want more control over what options are taken into account when generating the locations, you can create a `LocationOptions` object, configure it to your liking, and start the engine with it.

```java
// ...

// Create a new LocationOptions object. By default all options are enabled.
LocationOptions locationOptions = new LocationOptions();

// Use WiFi and satellite (GNSS) positioning only.
locationOptions.wifiPositioningOptions.enabled = true
locationOptions.satellitePositioningOptions.enabled = true
locationOptions.sensorOptions.enabled = false;
locationOptions.cellularPositioningOptions.enabled = false

// Receive a location approximately every minute, but not more often than every 30 seconds.
locationOptions.notificationOptions.smallestIntervalMilliseconds = TimeUnit.SECONDS.toMillis(30);
locationOptions.notificationOptions.desiredIntervalMilliseconds = TimeUnit.SECONDS.toMillis(60);

locationEngine.start(locationOptions);

// ...
```

The table below shows an overview of the available `LocationAccuracy` modes, and how they are internally translated to `LocationOptions`:

<center><p>
<table>
  <tr>
    <th>LocationAccuracy</th>
    <th>LocationOptions</th>
  </tr>
  <tr>
    <td>BEST_AVAILABLE</td>
    <td>
        cellularPositioningOptions.enabled = true <br>
        satellitePositioningOptions.enabled = true <br>
        wifiPositioningOptions.enabled = true <br>
        sensorOptions.enabled = true <br>
        notificationOptions.desired_interval_millisec = 30000 (30s) <br>
        notificationOptions.smallest_interval_millisec = 1000 (1s) <br>
    </td>
  </tr>
  <tr>
    <td>NAVIGATION</td>
    <td>
        cellularPositioningOptions.enabled = false <br>
        satellitePositioningOptions.enabled = true <br>
        wifiPositioningOptions.enabled = true <br>
        sensorOptions.enabled = true <br>
        notificationOptions.desired_interval_millisec = 1000 (1s) <br>
        notificationOptions.smallest_interval_millisec = 1000 (1s) <br>
    </td>
  </tr>
  <tr>
    <td>SUB_METER_NAVIGATION</td>
    <td>
        cellularPositioningOptions.enabled = false <br>
        satellitePositioningOptions.enabled = true <br>
        satellitePositioningOptions.hdEnabled = true <br>
        wifiPositioningOptions.enabled = true <br>
        sensorOptions.enabled = true <br>
        notificationOptions.desired_interval_millisec = 1000 (1s) <br>
        notificationOptions.smallest_interval_millisec = 1000 (1s) <br>
    </td>
  </tr>
  <tr>
    <td>TENS_OF_METERS</td>
    <td>
        cellularPositioningOptions.enabled = false <br>
        satellitePositioningOptions.enabled = false <br>
        wifiPositioningOptions.enabled = true <br>
        sensorOptions.enabled = true <br>
        notificationOptions.desired_interval_millisec = 30000 (30s) <br>
        notificationOptions.smallest_interval_millisec = 1000 (1s) <br>
    </td>
  </tr>
  <tr>
    <td>HUNDREDS_OF_METERS</td>
    <td>
        cellularPositioningOptions.enabled = true <br>
        satellitePositioningOptions.enabled = false <br>
        wifiPositioningOptions.enabled = true <br>
        sensorOptions.enabled = false <br>
        notificationOptions.desired_interval_millisec = 30000 (30s) <br>
        notificationOptions.smallest_interval_millisec = 1000 (1s) <br>
    </td>
  </tr>
  <tr>
    <td>KILOMETERS</td>
    <td>
        cellularPositioningOptions.enabled = true <br>
        satellitePositioningOptions.enabled = false <br>
        wifiPositioningOptions.enabled = false <br>
        sensorOptions.enabled = false <br>
        notificationOptions.desired_interval_millisec = 30000 (30s) <br>
        notificationOptions.smallest_interval_millisec = 1000 (1s) <br>
    </td>
  </tr>
</table>
</p></center>

> #### Note
> The desired interval is not guaranteed by the `LocationEngine`, so it is possible that the locations will be delivered more or less often. The smallest  interval, on the other hand, guarantees that the locations are not provided more often than the defined value.

## Optimizing GNSS battery consumption

The update rate of GNSS (Global Navigation Satellite System) can be managed through the `smallest interval` setting. This setting defines the desired time interval between GNSS location updates requested from the Android OS.

In scenarios where high-frequency GNSS updates (such as 1 Hz) are not required, increasing the time between location updates can reduce battery consumption. The device's GNSS system uses less power while still providing location data at a rate suitable to the application's needs.

For example, if an application does not need precise real-time tracking, increasing the interval between updates can offer significant power savings, extending the battery life of the device.

## Add sub-meter precision

Starting the `LocationEngine` with `LocationAccuracy.SUB_METER_NAVIGATION` mode will enable HERE HD GNSS positioning. The HD GNSS (**H**igh **D**efinition **G**lobal **N**avigation **S**atellite **S**ystem) feature will allow high definition positioning for various use cases from lane assistance and turn-by-turn guidance to augmented reality. HD GNSS is a cloud-based solution that enables mass market devices to achieve sub-meter accuracy across the globe.

HD GNSS has special requirements for used Android devices. For this feature to work, Android version of the device has to be at least 12 (API 31). More specifically, device must support the following:

- Raw GNSS measurements
- GNSS carrier phase measurements (ADR)
- Dual frequency GNSS receiver (L5)

See also [Android documentation](https://developer.android.com/guide/topics/sensors/gnss) for more details.

It is the responsibility of the user to ensure conditions above hold with the used device. If not, the desired accuracy level may not be reached.

Conditions above do hold for some Android devices with earlier versions also. It is possible to successfully use `LocationAccuracy.SUB_METER_NAVIGATION` mode with some of these versions but this should only be done for development and testing purposes.

<center><p>
  <img src="../graphics/accuracy_without_hd_gnss.PNG" width="250" />
  <img src="../graphics/accuracy_with_hd_gnss.png" width="250" />
  <figcaption>Example comparison of ground track accuracy of traditional GNSS solution (left) and HERE HD GNSS solution (right).</figcaption>
</p></center>

By default, this feature is **not** available. HD Positioning needs to be activated separately: Users need to require enabled credentials to gain access to HERE HD GNSS correction data. <!-- markdown-link-check-disable --> [Contact us](https://www.here.com/platform/positioning) <!-- markdown-link-check-enable --> for more details.

> #### Note
> Even if `LocationAccuracy.SUB_METER_NAVIGATION` mode is used, it does not ensure that it will be used in every case, but fallback to other positioning sources and technologies may occur. Typical reasons for this include device not having necessary capabilities, use in environments which can be considered urban where GNSS measurements have lower quality, or when the credentials are not enabled for this feature. For more information about device capabilities and measurement quality, implement the `LocationIssueListener` interface and register it with the location engine's `addLocationIssueListener()` method. Check the API Reference for more information on the different issues.

## Handle location accuracy

Except for the coordinates and the timestamp, all other `Location` fields are optional. For example, the received `Location` object may contain the information about the bearing angle, as well as the current speed, but this is not guaranteed to be available. Unavailable values will be returned as `null`. What kind of sources are used for positioning (as defined by the above mentioned `LocationOptions`), and the device's capabilities affect what fields will be available.

```java
if (location.speedInMetersPerSecond != null) {
    Log.d(TAG, "Speed (m/s): " + location.speedInMetersPerSecond);
} else {
    Log.d(TAG, "Speed (m/s): Not available");
}
```

The `horizontalAccuracyInMeters` field, which is present in the `Location` object, also known as the "radius of uncertainty", provides an estimate of the area within which the true geographic coordinates are likely to lie with a 68% probability. This is used to draw a halo indicator around the current location. The illustration below depicts the inner green circle as the `location.coordinates` and the surrounding circle as the accuracy circle with a radius of `horizontalAccuracyInMeters`. The true geographical coordinates may lie inside (68%) or outside (32%) the accuracy circle.

<center><p>
  <img src="../graphics/location_accuracy.png" width="450" />
  <figcaption>Illustration: Radius of horizontal uncertainty and vertical uncertainty.</figcaption>
</p></center>

Likewise, in the case of altitude, if the `verticalAccuracyInMeters` value is 10 meters, this indicates that the actual altitude is expected to fall within a range of altitude - 10m to altitude + 10m with a probability of 68%. Other accuracy values, like `bearingAccuracyInDegrees` and `speedAccuracyInMetersPerSecond` will follow the same rule: a smaller uncertainty results in a better accuracy.

> #### Note
> On Android devices, the `coordinates.altitude` value is given in relation to the WGS 84 reference ellipsoid.

### Achieving probabilities other than 68% (CEP68)

What if the given probability of 68% (CEP68) is not enough - is it possible to achieve an accuracy of 99%? Yes, it is: Since the given circular error probability (CEP) follows a chi-squared distribution with two degrees-of-freedom, it is easy to calculate the desired probability based on the following formulas:

<center><p>
<table style="width:500">
  <tr>
    <th>Probability</th>
    <th>Radius of Uncertainty</th>
  </tr>
  <tr>
    <td>50%</td>
    <td>CEP50 = 0.78 x CEP68</td>
  </tr>
  <tr>
    <td>60%</td>
    <td>CEP60 = 0.90 x CEP68</td>
  </tr>
  <tr>
    <td>70%</td>
    <td>CEP70 = 1.03 x CEP68</td>
  </tr>
  <tr>
    <td>80%</td>
    <td>CEP80 = 1.19 x CEP68</td>
  </tr>
  <tr>
    <td>90%</td>
    <td>CEP90 = 1.42 x CEP68</td>
  </tr>
  <tr>
    <td>95%</td>
    <td>CEP95 = 1.62 x CEP68</td>
  </tr>
  <tr>
    <td>99%</td>
    <td>CEP99 = 2.01 x CEP68</td>
  </tr>
</table>
</p></center>

The table above can be used to visualize various probability levels for a halo indicator on the map. For example, if the horizontal accuracy is 20 meters, you can (roughly) double the radius to achieve a probability of 99%. The accuracy value is always given as CEP68, that means:

**CEP99 = 2.01 x CEP68 = 2.01 x 20m = 40.2m**

Now you can draw a radius of 40.2 meters around the found location - and with a probability of 99%, the real location will lie within that circle. On the other hand, the probability for a radius of 0 meters is 0%.

## Print your current location as text

The following implementation shows an example of how to textually print the location information received in each update.

```java
public class MainActivity extends AppCompatActivity {

    // ...

    // TextViews to display Location information to the user
    private TextView mLatitudeValue;
    private TextView mLongitudeValue;
    private TextView mAltitudeValue;
    private TextView mBearingValue;
    private TextView mBearingAccuracyValue;
    private TextView mSpeedValue;
    private TextView mSpeedAccuracyValue;
    private TextView mHorizontalAccuracyValue;
    private TextView mVerticalAccuracyValue;
    private TextView mTimestampValue;
    private TextView mTimestampReadableValue;
    private TextView mTimestampSincebootValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // ...

        try {
            consentEngine = new ConsentEngine();
            locationEngine = new LocationEngine();
        } catch (InstantiationErrorException e) {
            throw new RuntimeException("Initialization failed: " + e.getMessage());
        }

        mLatitudeValue = findViewById(R.id.lat_value);
        mLongitudeValue = findViewById(R.id.lon_value);
        mHorizontalAccuracyValue = findViewById(R.id.hor_accuracy_value);
        mAltitudeValue = findViewById(R.id.alt_value);
        mVerticalAccuracyValue = findViewById(R.id.ver_accuracy_value);
        mBearingValue = findViewById(R.id.bearing_value);
        mBearingAccuracyValue = findViewById(R.id.bearing_accuracy_value);
        mSpeedValue = findViewById(R.id.speed_value);
        mSpeedAccuracyValue = findViewById(R.id.speed_accuracy_value);
        mTimestampValue = findViewById(R.id.timestamp_value);
        mTimestampReadableValue = findViewById(R.id.timestamp_readable_value);
        mTimestampSincebootValue = findViewById(R.id.timestamp_since_boot_value);

        // Request permissions from the user
        handleAndroidPermissions();
    }

    private void handleAndroidPermissions() {
        permissionsRequestor = new PermissionsRequestor(this);
        permissionsRequestor.request(new ResultListener(){

            @Override
            public void permissionsGranted() {
                if (consentEngine.getUserConsentState() == Consent.UserReply.NOT_HANDLED) {
                    consentEngine.requestUserConsent();
                }

                // We start location updates once al permissions have been granted
                startLocating();
            }

            @Override
            public void permissionsDenied() {
                Log.e(TAG, "Permissions denied by user.");
            }
        });
    }

    private final LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationUpdated(@NonNull Location location) {
            // Populate the TextViews with the received location information.
            populate(location);
        }
    };

    public void populate(Location location) {
        mLatitudeValue.setText(String.format(Locale.US, "%.5f %s", location.coordinates.latitude, "°"));
        mLongitudeValue.setText(String.format(Locale.US, "%.5f %s", location.coordinates.longitude, "°"));
        mAltitudeValue.setText(location.coordinates.altitude != null ? String.format(Locale.US, "%.5f %s", location.coordinates.altitude, "meters") : "-");
        mBearingValue.setText(location.bearingInDegrees != null ? String.format(Locale.US, "%.5f %s", location.bearingInDegrees, "°") : "-");
        mBearingAccuracyValue.setText(location.bearingAccuracyInDegrees != null ? String.format(Locale.US, "%.5f %s", location.bearingAccuracyInDegrees, "°") : "-");
        mSpeedValue.setText(location.speedInMetersPerSecond != null ? String.format(Locale.US, "%.5f %s", location.speedInMetersPerSecond, "m/s") : "-");
        mSpeedAccuracyValue.setText(location.speedAccuracyInMetersPerSecond != null ? String.format(Locale.US, "%.5f %s", location.speedAccuracyInMetersPerSecond, "m/s") : "-");
        mHorizontalAccuracyValue.setText(location.horizontalAccuracyInMeters != null ? String.format(Locale.US, "%.5f %s", location.horizontalAccuracyInMeters, "meters") : "-");
        mVerticalAccuracyValue.setText(location.verticalAccuracyInMeters != null ? String.format(Locale.US, "%.5f %s", location.verticalAccuracyInMeters, "meters") : "-");
        mTimestampValue.setText(String.format(Locale.US, "%d %s", TimeUnit.MILLISECONDS.toSeconds(location.timestamp.getTime()), "seconds"));
        mTimestampReadableValue.setText(String.format(Locale.US, "%tc", location.timestamp));
        mTimestampSincebootValue.setText(location.timestampSinceBootInMilliseconds != null ? String.format(Locale.US, "%d %s", location.timestampSinceBootInMilliseconds, "milliseconds") : "-");
    }
```

This example can be useful to debug location signals. The code can be found as part of the "Positioning" example app you can find on [GitHub](https://github.com/heremaps/here-sdk-examples/tree/master/examples/latest/navigate/android/Positioning).
