## Implementation of the CRERoutingEngine

```java

import android.util.Log;

import androidx.annotation.Nullable;

import com.google.gson.Gson;
import com.here.common.RESTEngine;
import com.here.sdk.core.GeoCoordinates;
import com.here.sdk.core.Location;
import com.here.sdk.core.errors.InstantiationErrorException;
import com.here.sdk.routing.CalculateRouteCallback;
import com.here.sdk.routing.Route;
import com.here.sdk.routing.RoutingEngine;
import com.here.sdk.routing.RoutingError;
import com.here.sdk.routing.TruckOptions;

import java.util.ArrayList;
import java.util.List;

// A class to calculate routes using custom map data uploaded to the HERE Fleet Telematics backend.
public class CRERoutingEngine {

    private static final String TAG = CRERoutingEngine.class.getName();

    private final String apiKey;
    private final RoutingEngine routingEngine;
    private final RESTEngine restEngine;

    /**
     * The RouteResultCallback interface defines a callback method to handle the results of a routing operation
     * executed with the FT REST API and the HERE SDK. After receiving the route geometry from the FT API,
     * a new Route will be calculated based on this geometry with the HERE SDK.
     */
    public interface RouteResultCallback {

        /**
         * Called when the routing operation has completed, providing the results of the operation.
         *
         * @param originalRouteGeometry A list of {@link GeoCoordinates} representing the geometry of the original FT route.
         *                              This is null when routingError is not null.
         * @param routingError          An instance of {@link RoutingError} containing details about an error
         *                              encountered during the routing operation. This is null if the operation
         *                              completed successfully without errors.
         * @param importedRoutes        A list of {@link Route} objects representing routes that were
         *                              successfully imported.
         *                              This is null when routingError is not null.
         */
        void onResult(@Nullable List<GeoCoordinates> originalRouteGeometry,
                      @Nullable RoutingError routingError,
                      @Nullable List<Route> importedRoutes);
    }

    public CRERoutingEngine(String apiKey) {
        this.apiKey = apiKey;

        restEngine = new RESTEngine();

        try {
            routingEngine = new RoutingEngine();
        } catch (InstantiationErrorException e) {
            throw new RuntimeException("Initialization of RoutingEngine failed: " + e.error.name());
        }
    }

    public void calculateRoute(GeoCoordinates start, GeoCoordinates dest, String overlayName, RouteResultCallback callback) {
        // The URL to create a REST API call to the Fleet Telematics backend.
        String urlStr = "https://fleet.api.here.com/2/calculateroute.json?"
                + "overlays=" + overlayName
                + "&waypoint0=" + mergeLatLonToString(start)
                + "&waypoint1=" + mergeLatLonToString(dest)
                + "&apiKey=" + apiKey
                + "&mode=fastest;truck;traffic:enabled&alternatives=0";

        restEngine.initiateGETRequest(urlStr, new RESTEngine.ResultCallback() {
            @Override
            public void onResult(int httpStatus, @Nullable RESTEngine.RESTEngineError error, @Nullable String jsonString) {
                if (error != null) {
                    Log.e(TAG, "Error: " + error.name());
                    Log.e(TAG, "HTTP status code: " + httpStatus);
                    List<GeoCoordinates> routeGeometry = null;
                    List<Route> routes = null;
                    callback.onResult(routeGeometry, RoutingError.HTTP_ERROR, routes);
                    return;
                }

                parseJsonResponse(jsonString, callback);
            }
        });
    }

    private String mergeLatLonToString(GeoCoordinates geoCoordinates) {
        return geoCoordinates.latitude + "," + geoCoordinates.longitude;
    }

    private void parseJsonResponse(String json, RouteResultCallback callback) {
        Log.d(TAG, json);
        Gson gson = new Gson();
        CREResponse response = gson.fromJson(json, CREResponse.class);

        List<GeoCoordinates> routeGeometry = extractCoordinates(response);
        importRoute(routeGeometry, callback);
    }

    // Adapt the parsing based on how you have defined your data.
    private static List<GeoCoordinates> extractCoordinates(CREResponse apiResponse) {
        List<GeoCoordinates> coordinates = new ArrayList<>();
        for (CRERoute route : apiResponse.response.route) {
            for (CRELeg leg : route.leg) {
                for (CRELink link : leg.link) {
                    List<Double> shapePoints = link.shape;
                    for (int i = 0; i < shapePoints.size(); i += 2) {
                        double latitude = shapePoints.get(i);
                        double longitude = shapePoints.get(i + 1);
                        coordinates.add(new GeoCoordinates(latitude, longitude));
                    }
                }
            }
        }
        return coordinates;
    }

    private void importRoute(List<GeoCoordinates> routeGeometry, RouteResultCallback callback) {
        List<Location> locations = new ArrayList<>();
        for (GeoCoordinates geoCoordinatesItem : routeGeometry) {
            locations.add(new Location(geoCoordinatesItem));
        }

        routingEngine.importRoute(locations, new TruckOptions(), new CalculateRouteCallback() {
            @Override
            public void onRouteCalculated(@Nullable RoutingError routingError, @Nullable List<Route> routes) {
                callback.onResult(routeGeometry, routingError, routes);
            }
        });
    }
}
```
